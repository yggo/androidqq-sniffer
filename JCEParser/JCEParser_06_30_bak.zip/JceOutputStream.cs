﻿using DotNetty.Buffers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YgAndroidQQSniffer.JCEParser
{
    public class JceOutputStream
    {
        private IByteBuffer _bs;

        protected Encoding ServerEncoding;

        public JceOutputStream(IByteBuffer bs)
        {
            ServerEncoding = Encoding.UTF8;
            _bs = bs;
        }

        public JceOutputStream(int capacity)
        {
            ServerEncoding = Encoding.UTF8;
            _bs = Unpooled.Buffer(capacity);
        }

        public JceOutputStream() : this(128)
        {
        }

        public void WriteHead(byte type, int tag)
        {
            if (tag < 15)
            {
                byte b = (byte)(tag << 4 | type);
                _bs.WriteByte(b);
            }
            else if (tag < 256)
            {
                byte b = (byte)(0xF0 | type);
                _bs.WriteByte(b);
                _bs.WriteByte(tag);
            }
            else
            {
                throw new JceEncodeException("tag is too large: " + tag);
            }
        }
    }
}
