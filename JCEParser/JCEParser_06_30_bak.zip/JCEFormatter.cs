﻿using DotNetty.Buffers;
using System;
using System.ComponentModel.DataAnnotations;
using System.Text;
using YgAndroidQQSniffer.TLVParser;

namespace YgAndroidQQSniffer.JCEParser
{
    public enum JceStruct
    {
        [Display(Name = "0", Description = "byte")]
        BYTE,
        [Display(Name = "1", Description = "short")]
        SHORT,
        [Display(Name = "2", Description = "int")]
        INT,
        [Display(Name = "3", Description = "long")]
        LONG,
        [Display(Name = "4", Description = "float")]
        FLOAT,
        [Display(Name = "5", Description = "double")]
        DOUBLE,
        [Display(Name = "6", Description = "string1")]
        STRING1,
        [Display(Name = "7", Description = "string4")]
        STRING4,
        [Display(Name = "8", Description = "map")]
        MAP,
        [Display(Name = "9", Description = "list")]
        LIST,
        [Display(Name = "10", Description = "struct_begin")]
        STRUCT_BEGIN,
        [Display(Name = "11", Description = "struct_end")]
        STRUCT_END,
        [Display(Name = "12", Description = "zero_tag")]
        ZERO_TAG,
        [Display(Name = "13", Description = "simple_list")]
        SIMPLE_LIST
    }
    public class HeadData
    {
        public byte Type;
        public int Tag;
        public JceStruct JceType;

        public void Clear()
        {
            Type = 0;
            Tag = 0;
        }
    }
    public class JCEFormatter : IParser
    {
        private IByteBuffer _buf { get; set; }
        private StringBuilder _sb { get; set; } = new StringBuilder();
        private int _pad { get; set; }

        private HeadData ReadHead(bool isMove = true)
        {
            HeadData hd = new HeadData();
            byte b;
            if (isMove)
            {
                b = _buf.ReadByte();
            }
            else
            {
                b = _buf.GetByte(_buf.ReaderIndex);
            }
            hd.Type = (byte)(b & 0xF);
            hd.JceType = (JceStruct)hd.Type;
            hd.Tag = (b & 0xF0) >> 4;
            if (hd.Tag == 15)
            {
                if (isMove)
                {
                    hd.Tag = _buf.ReadByte() & 0xFF;
                }
                else
                {
                    hd.Tag = _buf.GetByte(_buf.ReaderIndex + 1) & 0xFF;
                }
            }
            return hd;
        }

        private void ReadByte()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadByte()).Append(Environment.NewLine);
        }

        private void ReadShort()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadShort()).Append(Environment.NewLine);
        }

        private void ReadInt()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadInt()).Append(Environment.NewLine);
        }

        private void ReadLong()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadLong()).Append(Environment.NewLine);
        }

        private void ReadFloat()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadFloat()).Append(Environment.NewLine);
        }

        private void ReadDouble()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadDouble()).Append(Environment.NewLine);
        }

        private void ReadString1()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            int len = _buf.ReadByte();
            if (len < 0) len += 256;
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadCharSequence(len, Encoding.UTF8)).Append(Environment.NewLine);
        }

        private void ReadString4()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            int len = _buf.ReadInt();
            if (len > (100 * 1024 * 1024) || len < 0)
            {
                throw new Exception("string too long: " + len);
            }
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadCharSequence(len, Encoding.UTF8)).Append(Environment.NewLine);
        }

        private void ReadZeroTag()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(0).Append(Environment.NewLine);
        }

        private void ReadMap()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            HeadData subHd = ReadHead();
            if (subHd.JceType == JceStruct.ZERO_TAG)
            {
                _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append("0, {}").Append(Environment.NewLine);
            }
            else if (subHd.JceType == JceStruct.BYTE)
            {
                int item_count = _buf.ReadByte();
                _pad += 2;
                //TODO left { should be like ReadList [
                _sb.Append("[0 8]{").Append(Environment.NewLine);
                for (int i = 0; i < item_count; i++)
                {
                    string key = ReadMapKey();
                    byte[] value = ReadMapValue();
                    PrettyPadding();
                    _sb.Append($"key: {key} value: {value.HexDump()}").Append(Environment.NewLine);
                }
                _pad -= 2;
                _sb.Append("}");
            }
            else
            {
                throw new Exception("ReadMap cannot process JceType: " + subHd.JceType);
            }
        }

        private string ReadString()
        {
            HeadData hd = ReadHead();
            if (hd.JceType == JceStruct.STRING1)
            {
                int len = _buf.ReadByte();
                if (len < 0) len += 256;
                return _buf.ReadCharSequence(len, Encoding.UTF8).ToString();
            }
            else if (hd.JceType == JceStruct.STRING4)
            {
                int len = _buf.ReadInt();
                if (len > (100 * 1024 * 1024) || len < 0)
                {
                    throw new Exception("string too long: " + len);
                }
                return _buf.ReadCharSequence(len, Encoding.UTF8).ToString();
            }
            else
            {
                throw new Exception("ReadString invalid JceType: " + hd.JceType);
            }
        }

        private string ReadMapKey()
        {
            return ReadString();
        }

        private byte[] ReadMapValue()
        {
            HeadData hd = ReadHead();
            if (hd.JceType == JceStruct.SIMPLE_LIST)
            {
                ReadHead();
                HeadData subHd = ReadHead();
                int len;
                if (subHd.JceType == JceStruct.BYTE)
                {
                    len = _buf.ReadByte();
                }
                else if (subHd.JceType == JceStruct.SHORT)
                {
                    len = _buf.ReadShort();
                }
                /*else if (subHd.JceType == JceStruct.INT)
                {
                    //todo 这个可能不会有 暂时没遇到那么长的
                    len = _buf.ReadInt();
                }*/
                else
                {
                    throw new Exception("ReadSimpleList cannot process JceType: " + subHd.JceType);
                }
                return _buf.ReadBytes(len).Array;
            }
            else
            {
                throw new Exception("ReadMap SubItem invalid value JceType: " + hd.JceType);
            }
        }

        private void ReadList()
        {
            //TODO PrettyPadding[Tag Type]
            HeadData hd = ReadHead();
            int size = _buf.ReadShort();
            PrettyPadding();
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(Environment.NewLine);
            PrettyPadding();
            _sb.Append("[").Append(Environment.NewLine);
            _pad += 4;
            //elem可能是多个其他的Struct 0A开头0B结尾
            Console.WriteLine("ReadList size: " + size);
            for (int i = 0; i < size; i++)
            {
                HeadData tmp = ReadHead(false);
                switch (tmp.JceType)
                {
                    case JceStruct.BYTE:
                        ReadByte();
                        break;
                    case JceStruct.SHORT:
                        ReadShort();
                        break;
                    case JceStruct.INT:
                        ReadInt();
                        break;
                    case JceStruct.LONG:
                        ReadLong();
                        break;
                    case JceStruct.FLOAT:
                        ReadFloat();
                        break;
                    case JceStruct.DOUBLE:
                        ReadDouble();
                        break;
                    case JceStruct.STRING1:
                        ReadString1();
                        break;
                    case JceStruct.STRING4:
                        ReadString4();
                        break;
                    case JceStruct.MAP:
                    case JceStruct.LIST:
                        break;
                    case JceStruct.STRUCT_BEGIN:
                        HeadData tmp_hd;
                        //list 里面的结构体又包含其他的0A 0B，所以检测到0B就以为当前elem读取完了
                        //读取到begin就do while,do while里面再遇到还是do while一下
                        do
                        {
                            tmp_hd = ReadHead(false);
                            switch (tmp_hd.JceType)
                            {
                                case JceStruct.BYTE:
                                    ReadByte();
                                    break;
                                case JceStruct.SHORT:
                                    ReadShort();
                                    break;
                                case JceStruct.INT:
                                    ReadInt();
                                    break;
                                case JceStruct.LONG:
                                    ReadLong();
                                    break;
                                case JceStruct.FLOAT:
                                    ReadFloat();
                                    break;
                                case JceStruct.DOUBLE:
                                    ReadDouble();
                                    break;
                                case JceStruct.STRING1:
                                    ReadString1();
                                    break;
                                case JceStruct.STRING4:
                                    ReadString4();
                                    break;
                                case JceStruct.MAP:
                                    ReadMap();
                                    break;
                                case JceStruct.LIST:
                                    ReadList();
                                    break;
                                case JceStruct.STRUCT_BEGIN:
                                    HeadData t_hd;
                                    do
                                    {
                                        t_hd = ReadHead(false);
                                        switch (t_hd.JceType)
                                        {
                                            case JceStruct.BYTE:
                                                ReadByte();
                                                break;
                                            case JceStruct.SHORT:
                                                ReadShort();
                                                break;
                                            case JceStruct.INT:
                                                ReadInt();
                                                break;
                                            case JceStruct.LONG:
                                                ReadLong();
                                                break;
                                            case JceStruct.FLOAT:
                                                ReadFloat();
                                                break;
                                            case JceStruct.DOUBLE:
                                                ReadDouble();
                                                break;
                                            case JceStruct.STRING1:
                                                ReadString1();
                                                break;
                                            case JceStruct.STRING4:
                                                ReadString4();
                                                break;
                                            case JceStruct.MAP:
                                                ReadMap();
                                                break;
                                            case JceStruct.LIST:
                                                ReadList();
                                                break;
                                            case JceStruct.STRUCT_BEGIN:
                                                Console.WriteLine(11111111111);
                                                ReadStructBegin();
                                                break;
                                            case JceStruct.STRUCT_END:
                                                ReadStructEnd();
                                                break;
                                            case JceStruct.ZERO_TAG:
                                                ReadZeroTag();
                                                break;
                                            case JceStruct.SIMPLE_LIST:
                                                ReadSimpleList();
                                                break;
                                            default:
                                                throw new ArgumentException("type mismatch: " + t_hd.JceType);
                                        }
                                    } while (t_hd.JceType != JceStruct.STRUCT_END);
                                    break;
                                case JceStruct.STRUCT_END:
                                    ReadStructEnd();
                                    break;
                                case JceStruct.ZERO_TAG:
                                    ReadZeroTag();
                                    break;
                                case JceStruct.SIMPLE_LIST:
                                    ReadSimpleList();
                                    break;
                                default:
                                    throw new ArgumentException("type mismatch: " + tmp_hd.JceType);
                            }
                        } while (tmp_hd.JceType != JceStruct.STRUCT_END);
                        break;
                    /*case JceStruct.STRUCT_END:
                        ReadStructEnd();
                        break;*/
                    case JceStruct.ZERO_TAG:
                        ReadZeroTag();
                        break;
                    case JceStruct.SIMPLE_LIST:
                        ReadSimpleList();
                        break;
                    default:
                        throw new ArgumentException("ReadList item invalid JceType: " + tmp.JceType);
                }
                _sb.Append("--------------------------------------------------\n");
            }
            _pad -= 4;
            PrettyPadding();
            _sb.Append("]???????????????").Append(Environment.NewLine);
        }

        private void ReadSimpleList()
        {
            PrettyPadding();
            HeadData hd = ReadHead();
            _buf.ReadByte();
            HeadData subHd = ReadHead();
            int len = 0;
            if (subHd.JceType == JceStruct.BYTE)
            {
                len = _buf.ReadByte();
            }
            else if (subHd.JceType == JceStruct.SHORT)
            {
                len = _buf.ReadShort();
            }
            else if (subHd.JceType == JceStruct.INT)
            {
                len = _buf.ReadInt();
            }
            else if (subHd.JceType == JceStruct.ZERO_TAG)
            {
                //0 elem
                Console.WriteLine("0 elem");
            }
            else
            {
                throw new Exception("ReadSimpleList cannot process JceType: " + subHd.JceType);
            }
            _sb.Append($"[{hd.Tag} {hd.Type}]").Append(" ").Append(_buf.ReadBytes(len).HexDump()).Append(Environment.NewLine);
        }

        private void ReadStructBegin()
        {
            ReadHead();
            PrettyPadding();
            _sb.Append($"[0 10]").Append(Environment.NewLine);
            _pad += 2;
        }

        private void ReadStructEnd()
        {
            ReadHead();
            _pad -= 2;
            PrettyPadding();
            _sb.Append("[0 11]").Append(Environment.NewLine);
        }

        private void PrettyPadding()
        {
            for (int i = 0; i < _pad; i++)
            {
                _sb.Append(" ");
            }
        }

        public string Parse(IByteBuffer value)
        {
            _buf = value;

            /*ReadByte();
            ReadZeroTag();
            ReadZeroTag();
            ReadInt();
            ReadString1();
            ReadString1();
            ReadSimpleList();
            ReadZeroTag();
            ReadMap();
            ReadMap();*/

            //ReadMap();

            while (value.IsReadable())
            {
                HeadData hd = ReadHead(false);
                switch (hd.JceType)
                {
                    case JceStruct.BYTE:
                        ReadByte();
                        break;
                    case JceStruct.SHORT:
                        ReadShort();
                        break;
                    case JceStruct.INT:
                        ReadInt();
                        break;
                    case JceStruct.LONG:
                        ReadLong();
                        break;
                    case JceStruct.FLOAT:
                        ReadFloat();
                        break;
                    case JceStruct.DOUBLE:
                        ReadDouble();
                        break;
                    case JceStruct.STRING1:
                        ReadString1();
                        break;
                    case JceStruct.STRING4:
                        ReadString4();
                        break;
                    case JceStruct.MAP:
                        ReadMap();
                        break;
                    case JceStruct.LIST:
                        ReadList();
                        break;
                    case JceStruct.STRUCT_BEGIN:
                        ReadStructBegin();
                        break;
                    case JceStruct.STRUCT_END:
                        ReadStructEnd();
                        break;
                    case JceStruct.ZERO_TAG:
                        ReadZeroTag();
                        break;
                    case JceStruct.SIMPLE_LIST:
                        ReadSimpleList();
                        break;
                    default:
                        throw new ArgumentException("type mismatch: " + hd.JceType);
                }
            }
            return _sb.ToString();
        }
    }
}
