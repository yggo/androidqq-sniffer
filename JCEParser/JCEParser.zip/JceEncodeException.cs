﻿using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YgAndroidQQSniffer.JCEParser
{
    public class JceEncodeException : InvalidOperationException
    {
        public JceEncodeException(string message) : base(message)
        {
        }
    }
}
