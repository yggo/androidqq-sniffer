﻿using DotNetty.Buffers;
using System;
using System.Text;

namespace YgAndroidQQSniffer.JCEParser
{
    public class JceInputStream
    {
        private IByteBuffer _bs;

        protected Encoding ServerEncoding;

        public class HeadData
        {
            public byte Type;
            public int Tag;
            public void Clear()
            {
                Type = 0;
                Tag = 0;
            }
        }

        public JceInputStream()
        {
            ServerEncoding = Encoding.UTF8;
        }

        public JceInputStream(IByteBuffer bs)
        {
            ServerEncoding = Encoding.UTF8;
            _bs = bs;
        }

        public JceInputStream(byte[] bs)
        {
            ServerEncoding = Encoding.UTF8;
            _bs = Unpooled.WrappedBuffer(bs);
        }

        public JceInputStream(byte[] bs, int pos)
        {
            ServerEncoding = Encoding.UTF8;
            _bs = Unpooled.WrappedBuffer(bs);
            _bs.SetReaderIndex(pos);
        }

        public void Wrap(byte[] bs)
        {
            _bs = Unpooled.WrappedBuffer(bs);
        }

        public static int ReadHead(HeadData hd, IByteBuffer bb)
        {
            byte b = bb.ReadByte();
            hd.Type = (byte)(b & 0xF);
            hd.Tag = (b & 0xF0) >> 4;
            if (hd.Tag == 15)
            {
                hd.Tag = bb.ReadByte() & 0xFF;
                return 2;
            }
            return 1;
        }

        public void ReadHead(HeadData hd)
        {
            ReadHead(hd, _bs);
        }

        private int PeakHead(HeadData hd)
        {
            return ReadHead(hd, _bs.Duplicate());
        }

        private void Skip(int len)
        {
            _bs.SetReaderIndex(_bs.ReaderIndex + len);
        }

        public void SkipToStructEnd()
        {
            HeadData hd = new HeadData();
            do
            {
                ReadHead(hd);
                SkipField(hd.Type);
            } while (hd.Type != JceStruct.STRUCT_END);
        }

        private void SkipField()
        {
            HeadData hd = new HeadData();
            ReadHead(hd);
            SkipField(hd.Type);
        }

        private void SkipField(byte type)
        {
            int len;
            int size;
            HeadData hd;
            int i;
            int j;
            if (type == JceStruct.BYTE)
            {
                Skip(1);
            }
            else if (type == JceStruct.SHORT)
            {
                Skip(2);
            }
            else if (type == JceStruct.INT)
            {
                Skip(4);
            }
            else if (type == JceStruct.LONG)
            {
                Skip(8);
            }
            else if (type == JceStruct.FLOAT)
            {
                Skip(4);
            }
            else if (type == JceStruct.DOUBLE)
            {
                Skip(8);
            }
            else if (type == JceStruct.STRING1)
            {
                len = _bs.ReadByte();
                if (len < 0) len += 256;
                Skip(len);
            }
            else if (type == JceStruct.STRING4)
            {
                Skip(_bs.ReadInt());
            }
            else if (type == JceStruct.MAP)
            {
                size = Read(0, 0, true);
                for (i = 0; i < size * 2; i++)
                {
                    SkipField();
                }
            }
            else if (type == JceStruct.LIST)
            {
                size = Read(0, 0, true);
                for (i = 0; i < size; i++)
                {
                    SkipField();
                }
            }
            else if (type == JceStruct.SIMPLE_LIST)
            {
                hd = new HeadData();
                if (hd.Type != 0) throw new Exception("skipField with invalid type, type value: " + type + ", " + hd.Type);
                j = Read(0, 0, true);
                Skip(j);
            }
            else if (type == JceStruct.STRUCT_BEGIN)
            {
                SkipToStructEnd();
            }
            else if (type == JceStruct.STRUCT_END)
            {
                return;
            }
            else if (type == JceStruct.ZERO_TAG)
            {
                return;
            }
            else
            {
                throw new Exception("invalid type.");
            }
        }

        public bool SkipToTag(int tag)
        {
            try
            {
                HeadData hd = new HeadData();
                while (true)
                {
                    int len = PeakHead(hd);
                    if (hd.Type == JceStruct.STRUCT_END)
                    {
                        return false;
                    }
                    if (tag <= hd.Tag)
                    {
                        return (tag == hd.Tag);
                    }
                    Skip(len);
                    SkipField(hd.Type);
                }
            }
            catch (Exception) { }
            return false;
        }

        public bool Read(bool b, int tag, bool isRequire)
        {
            byte c = Read((byte)0, tag, isRequire);
            return (c != 0);
        }

        public byte Read(byte c, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    c = 0;
                    return c;
                }
                else if (hd.Type == JceStruct.BYTE)
                {
                    c = _bs.ReadByte();
                    return c;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return c;
        }

        public short Read(short n, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    n = 0;
                    return n;
                }
                else if (hd.Type == JceStruct.BYTE)
                {
                    n = _bs.ReadByte();
                    return n;
                }
                else if (hd.Type == JceStruct.SHORT)
                {
                    n = _bs.ReadShort();
                    return n;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return n;
        }

        public int Read(int n, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    n = 0;
                    return n;
                }
                else if (hd.Type == JceStruct.BYTE)
                {
                    n = _bs.ReadByte();
                    return n;
                }
                else if (hd.Type == JceStruct.SHORT)
                {
                    n = _bs.ReadShort();
                    return n;
                }
                else if (hd.Type == JceStruct.INT)
                {
                    n = _bs.ReadInt();
                    return n;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return n;
        }

        public long Read(long n, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    n = 0L;
                    return n;
                }
                else if (hd.Type == JceStruct.BYTE)
                {
                    n = _bs.ReadByte();
                    return n;
                }
                else if (hd.Type == JceStruct.SHORT)
                {
                    n = _bs.ReadShort();
                    return n;
                }
                else if (hd.Type == JceStruct.INT)
                {
                    n = _bs.ReadInt();
                    return n;
                }
                else if (hd.Type == JceStruct.LONG)
                {
                    n = _bs.ReadLong();
                    return n;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return n;
        }

        public float Read(float n, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    n = 0.0F;
                    return n;
                }
                else if (hd.Type == JceStruct.FLOAT)
                {
                    n = _bs.ReadFloat();
                    return n;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return n;
        }

        public double Read(double n, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.ZERO_TAG)
                {
                    n = 0.0D;
                    return n;
                }
                else if (hd.Type == JceStruct.FLOAT)
                {
                    n = _bs.ReadFloat();
                    return n;
                }
                else if (hd.Type == JceStruct.DOUBLE)
                {
                    n = _bs.ReadDouble();
                    return n;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return n;
        }

        public string Read(string s, int tag, bool isRequire)
        {
            if (SkipToTag(tag))
            {
                int len;
                byte[] ss;
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.STRING1)
                {
                    len = _bs.ReadByte();
                    if (len < 0) len += 256;
                    ss = new byte[len];
                    _bs.ReadBytes(ss);
                    try
                    {
                        s = Encoding.UTF8.GetString(ss);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return s;
                }
                else if (hd.Type == JceStruct.STRING4)
                {
                    len = _bs.ReadInt();
                    if (len > JceStruct.JCE_MAX_STRING_LENGTH || len < 0) throw new Exception("String too long: " + len);
                    ss = new byte[len];
                    _bs.ReadBytes(ss);
                    try
                    {
                        s = Encoding.UTF8.GetString(ss);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return s;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return s;
        }

        public byte[] Read(byte[] l, int tag, bool isRequire)
        {
            byte[] bytes = null;
            if (SkipToTag(tag))
            {
                HeadData hh;
                int size, j, i;
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.SIMPLE_LIST)
                {
                    hh = new HeadData();
                    ReadHead(hh);
                    if (hh.Type != 0) throw new Exception("type mismatch, tag: " + tag + ", type: " + hd.Type + ", " + hh.Type);
                    j = Read(0, 0, true);
                    if (j < 0) throw new Exception("invalid size, tag: " + tag + ", type: " + hd.Type + ", " + hh.Type + ", size: " + j);
                    bytes = new byte[j];
                    _bs.GetBytes(_bs.ReaderIndex, bytes);
                    return bytes;
                }
                else if (hd.Type == JceStruct.LIST)
                {
                    size = Read(0, 0, true);
                    if (size < 0) throw new Exception("size invalid: " + size);
                    bytes = new byte[size];
                    for (i = 0; i < size; i++)
                    {
                        bytes[i] = Read(bytes[0], 0, true);
                    }
                    return bytes;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return bytes;
        }

        public string ReadString(int tag, bool isRequire)
        {
            string s = string.Empty;
            if (SkipToTag(tag))
            {
                int len;
                byte[] ss;
                HeadData hd = new HeadData();
                ReadHead(hd);
                if (hd.Type == JceStruct.STRING1)
                {
                    len = _bs.ReadByte();
                    if (len < 0) len += 256;
                    ss = new byte[len];
                    _bs.ReadBytes(ss);
                    try
                    {
                        s = Encoding.UTF8.GetString(ss);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return s;
                }
                else if (hd.Type == JceStruct.STRING4)
                {
                    len = _bs.ReadInt();
                    if (len > JceStruct.JCE_MAX_STRING_LENGTH || len < 0) throw new Exception("String too long: " + len);
                    ss = new byte[len];
                    _bs.ReadBytes(ss);
                    try
                    {
                        s = Encoding.UTF8.GetString(ss);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    return s;
                }
                else
                {
                    throw new Exception("type mismatch.");
                }
            }
            if (isRequire) throw new Exception("require field not exist.");
            return s;
        }

    }
}
