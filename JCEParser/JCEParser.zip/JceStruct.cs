﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YgAndroidQQSniffer.JCEParser
{
    public abstract class JceStruct
    {
        public static readonly byte BYTE = 0;
        public static readonly byte SHORT = 1;
        public static readonly byte INT = 2;
        public static readonly byte LONG = 3;
        public static readonly byte FLOAT = 4;
        public static readonly byte DOUBLE = 5;
        public static readonly byte STRING1 = 6;
        public static readonly byte STRING4 = 7;
        public static readonly byte MAP = 8;
        public static readonly byte LIST = 9;
        public static readonly byte STRUCT_BEGIN = 10;
        public static readonly byte STRUCT_END = 11;
        public static readonly byte ZERO_TAG = 12;
        public static readonly byte SIMPLE_LIST = 13;
        public static readonly int JCE_MAX_STRING_LENGTH = 1024 * 1024 * 100;

        public abstract void WriteTo();

        public abstract void ReadFrom();
    }
}
