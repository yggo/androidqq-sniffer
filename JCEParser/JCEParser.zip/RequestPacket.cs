﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YgAndroidQQSniffer.JCEParser
{
    public class RequestPacket : JceStruct
    {
        public override void ReadFrom()
        {
            
        }

        public override void WriteTo()
        {
            throw new NotImplementedException();
        }
    }
}
