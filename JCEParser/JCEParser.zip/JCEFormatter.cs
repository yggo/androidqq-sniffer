﻿using DotNetty.Buffers;
using System;
using System.ComponentModel.DataAnnotations;
using System.Text;
using YgAndroidQQSniffer.Extension;
using YgAndroidQQSniffer.TLVParser;

namespace YgAndroidQQSniffer.JCEParser
{
    enum JceType
    {
        [Display(Name = "0", Description = "byte")]
        BYTE,
        [Display(Name = "1", Description = "short")]
        SHORT,
        [Display(Name = "2", Description = "int")]
        INT,
        [Display(Name = "3", Description = "long")]
        LONG,
        [Display(Name = "4", Description = "float")]
        FLOAT,
        [Display(Name = "5", Description = "double")]
        DOUBLE,
        [Display(Name = "6", Description = "string1")]
        STRING1,
        [Display(Name = "7", Description = "string4")]
        STRING4,
        [Display(Name = "8", Description = "map")]
        MAP,
        [Display(Name = "9", Description = "list")]
        LIST,
        [Display(Name = "10", Description = "struct_begin")]
        STRUCT_BEGIN,
        [Display(Name = "11", Description = "struct_end")]
        STRUCT_END,
        [Display(Name = "12", Description = "zero_tag")]
        ZERO_TAG,
        [Display(Name = "13", Description = "simple_list")]
        SIMPLE_LIST
    }
    public class HeadData
    {
        public byte Type;
        public int Tag;

        public void Clear()
        {
            Type = 0;
            Tag = 0;
        }
    }
    public class JCEFormatter : IParser
    {
        private IByteBuffer Buf { get; set; }
        private StringBuilder _sb = new StringBuilder();
        private int _pad 
        { 
            get; 
            set;
        }
        private void ReadHead(HeadData headData)
        {
            byte b = Buf.ReadByte();
            headData.Type = (byte)(b & 0xF);
            headData.Tag = (b & 0xF0) >> 4;
            if (headData.Tag == 15)
            {
                headData.Tag = Buf.ReadByte() & 0xFF;
            }
        }

        private void ReadString()
        {

        }

        private void ReadList(HeadData hd)
        {
            short size = Buf.ReadShort();
            var jceType = (JceType)hd.Type;

            for (int i = 0; i < _pad; i++) _sb.Append(" ");
            _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})]");
            _sb.Append("[\n");
            _pad += 4;
            for (int i = 0; i < _pad; i++) _sb.Append(" ");
            _sb.Append($"size: {size}").Append("\n");
            for (int i = 0; i < size; i++)
            {
                var subH = new HeadData();
                ReadHead(subH);
                var type = (JceType)subH.Type;

                if (type == JceType.BYTE)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{subH.Tag} {subH.Type}({type.GetDisplayDescription()})] {Buf.ReadByte()}").Append(Environment.NewLine);
                }
                else if (type == JceType.SHORT)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{i} 1({type.GetDisplayDescription()})] ").Append(Buf.ReadShort()).Append("\n");
                }
                else if (type == JceType.INT)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{i} 2({type.GetDisplayDescription()})] ").Append(Buf.ReadInt()).Append("\n");
                }
                else if (type == JceType.LONG)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{i} 3({type.GetDisplayDescription()})] ").Append(Buf.ReadLong()).Append("\n");
                }
                else if (type == JceType.STRING1)
                {
                    int str_len = Buf.ReadByte();
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{subH.Tag} {subH.Type}({type.GetDisplayDescription()})] {Buf.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                }
                else if (type == JceType.STRING4)
                {
                    int str_len = Buf.ReadInt();
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{subH.Tag} {subH.Type}({type.GetDisplayDescription()})] {Buf.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                }
                else if (type == JceType.STRUCT_BEGIN)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    //_pad += 2;
                    HeadData tmp_hd = new HeadData();
                    do
                    {
                        ReadHead(tmp_hd);
                        JceType tmp_jceType = (JceType)tmp_hd.Type;
                        if (tmp_jceType == JceType.BYTE)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadByte()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.SHORT)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadShort()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.INT)
                        {
                            //for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadInt()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.LONG)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadLong()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.FLOAT)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadFloat()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.DOUBLE)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadDouble()}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.STRING1)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            int str_len = Buf.ReadByte();
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.STRING4)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            int str_len = Buf.ReadInt();
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] {Buf.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.MAP)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            var hh = new HeadData();
                            ReadHead(hh);
                            if (hh.Type == 12)
                            {
                                _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] 0," + "{}").Append(Environment.NewLine);
                            }
                            else
                            {
                                short item_count = Buf.ReadByte();
                                _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})]").Append("{\n");
                                _sb.Append("  ").Append($"size: {item_count}").Append("\n");
                                for (int j = 0; j < item_count; j++)
                                {
                                    Buf.ReadByte();//skip string1 tag
                                    byte key_len = Buf.ReadByte();
                                    string key = Buf.ReadCharSequence(key_len, Encoding.UTF8).ToString();
                                    Buf.ReadByte();//skip simple_list tag
                                    var simple_list = ReadSimpleList();
                                    _sb.Append("  ").Append($"key: {key} value: {simple_list.HexDump()}").Append("\n");
                                    //_sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({jceType.GetDisplayDescription()})] key: {key} value: {simple_list.HexDump()}").Append(Environment.NewLine);
                                }
                                _sb.Append("}\n");
                            }
                        }
                        else if (tmp_jceType == JceType.LIST)
                        {
                            ReadList(tmp_hd);
                        }
                        else if (tmp_jceType == JceType.STRUCT_BEGIN)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _pad += 2;
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})]").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.STRUCT_END)
                        {
                            _pad -= 2;
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.ZERO_TAG)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] 0").Append(Environment.NewLine);
                        }
                        else if (tmp_jceType == JceType.SIMPLE_LIST)
                        {
                            for (int j = 0; j < _pad; j++) _sb.Append(" ");
                            var simple_list = ReadSimpleList();
                            _sb.Append($"[{tmp_hd.Tag} {tmp_hd.Type}({tmp_jceType.GetDisplayDescription()})] ").Append(simple_list.HexDump()).Append(Environment.NewLine);
                        }
                        else
                        {
                            throw new ArgumentException("unknown JceType: " + tmp_jceType);
                        }
                    } while (tmp_hd.Type != 11);
                }
                else if (type == JceType.ZERO_TAG)
                {
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{subH.Tag} {subH.Type}({type.GetDisplayDescription()})] 0").Append(Environment.NewLine);
                }
                else if (type == JceType.SIMPLE_LIST)
                {
                    var simple_list = ReadSimpleList();
                    for (int j = 0; j < _pad; j++) _sb.Append(" ");
                    _sb.Append($"[{i} 13({type.GetDisplayDescription()})] ").Append(simple_list.HexDump()).Append("\n");
                }
                else
                {
                    throw new Exception("cannot process type: " + type);
                }
            }
            _pad -= 4;
            for (int j = 0; j < _pad; j++) _sb.Append(" ");
            _sb.Append("]??????????????????\n");
        }

        private IByteBuffer ReadMap()
        {
            return null;
        }

        private IByteBuffer ReadSimpleList()
        {
            Buf.ReadByte();//skip unknown 1 byte 00
            var hh = new HeadData();
            ReadHead(hh);
            var jceType = (JceType)hh.Type;
            int list_len = 0;
            if (jceType == JceType.BYTE)
            {
                list_len = Buf.ReadByte();
            }
            else if (jceType == JceType.SHORT)
            {
                list_len = Buf.ReadShort();
            }
            else if (jceType == JceType.ZERO_TAG)
            {

            }
            else
            {
                Console.WriteLine("ReadSimpleList cannot process type: " + hh.Type);
            }
            IByteBuffer list_value = Buf.ReadBytes(list_len);
            return list_value;
        }

        public string Parse(IByteBuffer value)
        {
            Buf = value;
            if (Buf.ReadableBytes < 4)
            {
                throw new ArgumentException("decode package must include size head");
            }

            while (value.IsReadable())
            {
                var hd = new HeadData();
                ReadHead(hd);
                JceType jceType = (JceType)hd.Type;
                if (jceType == JceType.BYTE)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadByte()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.SHORT)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadShort()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.INT)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadInt()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.LONG)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadLong()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.FLOAT)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadFloat()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.DOUBLE)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadDouble()}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.STRING1)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    int str_len = value.ReadByte();
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.STRING4)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    int str_len = value.ReadInt();
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] {value.ReadCharSequence(str_len, Encoding.UTF8)}").Append(Environment.NewLine);
                }
                else if (jceType == JceType.MAP)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    var hh = new HeadData();
                    ReadHead(hh);
                    if (hh.Type == 12)
                    {
                        _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] 0," + "{}").Append(Environment.NewLine);
                    }
                    else
                    {
                        short item_count = Buf.ReadByte();
                        _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})]").Append("{\n");
                        _sb.Append("  ").Append($"size: {item_count}").Append("\n");
                        for (int i = 0; i < item_count; i++)
                        {
                            Buf.ReadByte();//skip string1 tag
                            byte key_len = Buf.ReadByte();
                            string key = Buf.ReadCharSequence(key_len, Encoding.UTF8).ToString();
                            Buf.ReadByte();//skip simple_list tag
                            var simple_list = ReadSimpleList();
                            _sb.Append("  ").Append($"key: {key} value: {simple_list.HexDump()}").Append("\n");
                            //_sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] key: {key} value: {simple_list.HexDump()}").Append(Environment.NewLine);
                        }
                        _sb.Append("}\n");
                    }
                }
                else if (jceType == JceType.LIST)
                {
                    ReadList(hd);
                }
                else if (jceType == JceType.STRUCT_BEGIN)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _pad += 2;
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})]").Append(Environment.NewLine);
                }
                else if (jceType == JceType.STRUCT_END)
                {
                    _pad -= 2;
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append(Environment.NewLine);
                    //_sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})]").Append(Environment.NewLine);
                }
                else if (jceType == JceType.ZERO_TAG)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] 0").Append(Environment.NewLine);
                }
                else if (jceType == JceType.SIMPLE_LIST)
                {
                    for (int i = 0; i < _pad; i++) _sb.Append(" ");
                    var simple_list = ReadSimpleList();
                    _sb.Append($"[{hd.Tag} {hd.Type}({jceType.GetDisplayDescription()})] ").Append(simple_list.HexDump()).Append(Environment.NewLine);
                }
                else
                {
                    throw new ArgumentException("unknown JceType: " + jceType);
                }
            }
            return _sb.ToString();
        }
    }
}
