﻿namespace YgAndroidQQSniffer
{
    partial class FormMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_network_adapter = new System.Windows.Forms.ComboBox();
            this.contextMenuStrip_analysis = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tEA解密ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.十六个0ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kEY日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.转换ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.到文本ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.到QQToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hex到时间ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hex到IPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Inflater解压ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.到10进制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.计算字节数ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tLV格式化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选中字节计算换行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一键格式化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button_start_capture = new System.Windows.Forms.Button();
            this.button_load_device = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.listView_packet_log = new System.Windows.Forms.ListView();
            this.Index = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Orientation = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SrcIp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.DstIp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PayloadLen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.PayloadData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip_packets = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制载荷数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.追踪流ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richTextBox_log = new System.Windows.Forms.RichTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView_analysis_log = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.contextMenuStrip_trace_flow = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制载荷数据ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button_stop_httpserver = new System.Windows.Forms.Button();
            this.button_start_httpserver = new System.Windows.Forms.Button();
            this.textBox_httpserver_port = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.richTextBox_httpserver_log = new System.Windows.Forms.RichTextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button_tea_key_log_decrypt = new System.Windows.Forms.Button();
            this.button_tea_copy_decrypt_data = new System.Windows.Forms.Button();
            this.button_tea_decrypt = new System.Windows.Forms.Button();
            this.button_tea_encrypt = new System.Windows.Forms.Button();
            this.textBox_tea_decrypt_data = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_tea_encrypt_data = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_tea_key = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox_tool_hookdata_nick = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_tgtkey = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox_tool_hookdata_A3 = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_A2 = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_A1 = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_d2key = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_bssid = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_imei = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_imsi = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_mac = new System.Windows.Forms.TextBox();
            this.textBox_tool_hookdata_androidId = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_tool_qqencrypt_pass = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button_tool_qqencrypt_copy = new System.Windows.Forms.Button();
            this.textBox_tool_qqencrypt_ret = new System.Windows.Forms.TextBox();
            this.button_tool_qqencrypt_calc = new System.Windows.Forms.Button();
            this.textBox_tool_qqencrypt_qq = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button_tool_md5_copy_once = new System.Windows.Forms.Button();
            this.textBox_tool_md5_once = new System.Windows.Forms.TextBox();
            this.button_tool_md5_calc = new System.Windows.Forms.Button();
            this.textBox_tool_md5_input = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button_tool_save_keys = new System.Windows.Forms.Button();
            this.button_tool_read_keys = new System.Windows.Forms.Button();
            this.textBox_tool_keys = new System.Windows.Forms.TextBox();
            this.button_stop_capture = new System.Windows.Forms.Button();
            this.button_clear_packet_log = new System.Windows.Forms.Button();
            this.button_clean_httpserver_log = new System.Windows.Forms.Button();
            this.contextMenuStrip_analysis.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip_packets.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.contextMenuStrip_trace_flow.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox_network_adapter
            // 
            this.comboBox_network_adapter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_network_adapter.FormattingEnabled = true;
            this.comboBox_network_adapter.Location = new System.Drawing.Point(12, 12);
            this.comboBox_network_adapter.Name = "comboBox_network_adapter";
            this.comboBox_network_adapter.Size = new System.Drawing.Size(367, 20);
            this.comboBox_network_adapter.TabIndex = 0;
            this.comboBox_network_adapter.SelectedIndexChanged += new System.EventHandler(this.ComboBox_network_adapter_SelectedIndexChanged);
            // 
            // contextMenuStrip_analysis
            // 
            this.contextMenuStrip_analysis.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tEA解密ToolStripMenuItem,
            this.转换ToolStripMenuItem,
            this.到10进制ToolStripMenuItem,
            this.计算字节数ToolStripMenuItem,
            this.tLV格式化ToolStripMenuItem,
            this.选中字节计算换行ToolStripMenuItem,
            this.一键格式化ToolStripMenuItem});
            this.contextMenuStrip_analysis.Name = "contextMenuStrip_analysis";
            this.contextMenuStrip_analysis.Size = new System.Drawing.Size(173, 158);
            // 
            // tEA解密ToolStripMenuItem
            // 
            this.tEA解密ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.十六个0ToolStripMenuItem,
            this.kEY日志ToolStripMenuItem});
            this.tEA解密ToolStripMenuItem.Name = "tEA解密ToolStripMenuItem";
            this.tEA解密ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.tEA解密ToolStripMenuItem.Text = "TEA解密";
            // 
            // 十六个0ToolStripMenuItem
            // 
            this.十六个0ToolStripMenuItem.Name = "十六个0ToolStripMenuItem";
            this.十六个0ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.十六个0ToolStripMenuItem.Text = "十六个0";
            this.十六个0ToolStripMenuItem.Click += new System.EventHandler(this.十六个0ToolStripMenuItem_Click);
            // 
            // kEY日志ToolStripMenuItem
            // 
            this.kEY日志ToolStripMenuItem.Name = "kEY日志ToolStripMenuItem";
            this.kEY日志ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.kEY日志ToolStripMenuItem.Text = "KEY日志";
            this.kEY日志ToolStripMenuItem.Click += new System.EventHandler(this.KEY日志ToolStripMenuItem_Click);
            // 
            // 转换ToolStripMenuItem
            // 
            this.转换ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.到文本ToolStripMenuItem,
            this.到QQToolStripMenuItem,
            this.hex到时间ToolStripMenuItem,
            this.hex到IPToolStripMenuItem,
            this.Inflater解压ToolStripMenuItem});
            this.转换ToolStripMenuItem.Name = "转换ToolStripMenuItem";
            this.转换ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.转换ToolStripMenuItem.Text = "转换";
            // 
            // 到文本ToolStripMenuItem
            // 
            this.到文本ToolStripMenuItem.Name = "到文本ToolStripMenuItem";
            this.到文本ToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.到文本ToolStripMenuItem.Text = "到文本";
            this.到文本ToolStripMenuItem.Click += new System.EventHandler(this.到文本ToolStripMenuItem_Click);
            // 
            // 到QQToolStripMenuItem
            // 
            this.到QQToolStripMenuItem.Name = "到QQToolStripMenuItem";
            this.到QQToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.到QQToolStripMenuItem.Text = "到QQ";
            this.到QQToolStripMenuItem.Click += new System.EventHandler(this.到QQToolStripMenuItem_Click);
            // 
            // hex到时间ToolStripMenuItem
            // 
            this.hex到时间ToolStripMenuItem.Name = "hex到时间ToolStripMenuItem";
            this.hex到时间ToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.hex到时间ToolStripMenuItem.Text = "Hex到时间";
            this.hex到时间ToolStripMenuItem.Click += new System.EventHandler(this.Hex到时间ToolStripMenuItem_Click);
            // 
            // hex到IPToolStripMenuItem
            // 
            this.hex到IPToolStripMenuItem.Name = "hex到IPToolStripMenuItem";
            this.hex到IPToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.hex到IPToolStripMenuItem.Text = "Hex到IP";
            this.hex到IPToolStripMenuItem.Click += new System.EventHandler(this.Hex到IPToolStripMenuItem_Click);
            // 
            // Inflater解压ToolStripMenuItem
            // 
            this.Inflater解压ToolStripMenuItem.Name = "Inflater解压ToolStripMenuItem";
            this.Inflater解压ToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.Inflater解压ToolStripMenuItem.Text = "Inflater解压";
            this.Inflater解压ToolStripMenuItem.Click += new System.EventHandler(this.Inflater解压ToolStripMenuItem_Click);
            // 
            // 到10进制ToolStripMenuItem
            // 
            this.到10进制ToolStripMenuItem.Name = "到10进制ToolStripMenuItem";
            this.到10进制ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.到10进制ToolStripMenuItem.Text = "到10进制";
            this.到10进制ToolStripMenuItem.Click += new System.EventHandler(this.到10进制ToolStripMenuItem_Click);
            // 
            // 计算字节数ToolStripMenuItem
            // 
            this.计算字节数ToolStripMenuItem.Name = "计算字节数ToolStripMenuItem";
            this.计算字节数ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.计算字节数ToolStripMenuItem.Text = "计算字节数";
            this.计算字节数ToolStripMenuItem.Click += new System.EventHandler(this.计算字节数ToolStripMenuItem_Click);
            // 
            // tLV格式化ToolStripMenuItem
            // 
            this.tLV格式化ToolStripMenuItem.Name = "tLV格式化ToolStripMenuItem";
            this.tLV格式化ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.tLV格式化ToolStripMenuItem.Text = "TLV格式化";
            this.tLV格式化ToolStripMenuItem.Click += new System.EventHandler(this.TLV格式化ToolStripMenuItem_Click);
            // 
            // 选中字节计算换行ToolStripMenuItem
            // 
            this.选中字节计算换行ToolStripMenuItem.Name = "选中字节计算换行ToolStripMenuItem";
            this.选中字节计算换行ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.选中字节计算换行ToolStripMenuItem.Text = "选中字节计算换行";
            this.选中字节计算换行ToolStripMenuItem.Click += new System.EventHandler(this.选中字节计算换行ToolStripMenuItem_Click);
            // 
            // 一键格式化ToolStripMenuItem
            // 
            this.一键格式化ToolStripMenuItem.Name = "一键格式化ToolStripMenuItem";
            this.一键格式化ToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.一键格式化ToolStripMenuItem.Text = "一键格式化";
            this.一键格式化ToolStripMenuItem.Click += new System.EventHandler(this.一键格式化ToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(822, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_start_capture
            // 
            this.button_start_capture.Location = new System.Drawing.Point(465, 10);
            this.button_start_capture.Name = "button_start_capture";
            this.button_start_capture.Size = new System.Drawing.Size(75, 23);
            this.button_start_capture.TabIndex = 5;
            this.button_start_capture.Text = "开始";
            this.button_start_capture.UseVisualStyleBackColor = true;
            this.button_start_capture.Click += new System.EventHandler(this.Button_start_capture_Click);
            // 
            // button_load_device
            // 
            this.button_load_device.Location = new System.Drawing.Point(385, 10);
            this.button_load_device.Name = "button_load_device";
            this.button_load_device.Size = new System.Drawing.Size(75, 23);
            this.button_load_device.TabIndex = 6;
            this.button_load_device.Text = "读取网卡";
            this.button_load_device.UseVisualStyleBackColor = true;
            this.button_load_device.Click += new System.EventHandler(this.Button_load_device_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(1, 39);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1128, 609);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1120, 583);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "抓包";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.listView_packet_log);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.richTextBox_log);
            this.splitContainer1.Size = new System.Drawing.Size(1114, 577);
            this.splitContainer1.SplitterDistance = 288;
            this.splitContainer1.TabIndex = 6;
            // 
            // listView_packet_log
            // 
            this.listView_packet_log.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Index,
            this.Orientation,
            this.SrcIp,
            this.DstIp,
            this.time,
            this.PayloadLen,
            this.PayloadData,
            this.columnHeader1,
            this.columnHeader2});
            this.listView_packet_log.ContextMenuStrip = this.contextMenuStrip_packets;
            this.listView_packet_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_packet_log.FullRowSelect = true;
            this.listView_packet_log.GridLines = true;
            this.listView_packet_log.HideSelection = false;
            this.listView_packet_log.Location = new System.Drawing.Point(0, 0);
            this.listView_packet_log.Name = "listView_packet_log";
            this.listView_packet_log.Size = new System.Drawing.Size(1114, 288);
            this.listView_packet_log.TabIndex = 6;
            this.listView_packet_log.UseCompatibleStateImageBehavior = false;
            this.listView_packet_log.View = System.Windows.Forms.View.Details;
            // 
            // Index
            // 
            this.Index.Text = "序号";
            // 
            // Orientation
            // 
            this.Orientation.Text = "方向";
            // 
            // SrcIp
            // 
            this.SrcIp.Text = "源地址";
            this.SrcIp.Width = 120;
            // 
            // DstIp
            // 
            this.DstIp.Text = "目的地址";
            this.DstIp.Width = 120;
            // 
            // time
            // 
            this.time.Text = "捕获时间";
            this.time.Width = 126;
            // 
            // PayloadLen
            // 
            this.PayloadLen.Text = "载荷长度(byte)";
            this.PayloadLen.Width = 107;
            // 
            // PayloadData
            // 
            this.PayloadData.Text = "载荷数据";
            this.PayloadData.Width = 505;
            // 
            // contextMenuStrip_packets
            // 
            this.contextMenuStrip_packets.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制载荷数据ToolStripMenuItem,
            this.追踪流ToolStripMenuItem});
            this.contextMenuStrip_packets.Name = "contextMenuStrip_packets";
            this.contextMenuStrip_packets.Size = new System.Drawing.Size(149, 48);
            // 
            // 复制载荷数据ToolStripMenuItem
            // 
            this.复制载荷数据ToolStripMenuItem.Name = "复制载荷数据ToolStripMenuItem";
            this.复制载荷数据ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.复制载荷数据ToolStripMenuItem.Text = "复制载荷数据";
            this.复制载荷数据ToolStripMenuItem.Click += new System.EventHandler(this.复制载荷数据ToolStripMenuItem_Click);
            // 
            // 追踪流ToolStripMenuItem
            // 
            this.追踪流ToolStripMenuItem.Name = "追踪流ToolStripMenuItem";
            this.追踪流ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.追踪流ToolStripMenuItem.Text = "追踪流";
            this.追踪流ToolStripMenuItem.Click += new System.EventHandler(this.追踪流ToolStripMenuItem_Click);
            // 
            // richTextBox_log
            // 
            this.richTextBox_log.ContextMenuStrip = this.contextMenuStrip_analysis;
            this.richTextBox_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_log.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.richTextBox_log.Location = new System.Drawing.Point(0, 0);
            this.richTextBox_log.Name = "richTextBox_log";
            this.richTextBox_log.Size = new System.Drawing.Size(1114, 285);
            this.richTextBox_log.TabIndex = 5;
            this.richTextBox_log.Text = "";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listView_analysis_log);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1120, 583);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "分析";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listView_analysis_log
            // 
            this.listView_analysis_log.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader12});
            this.listView_analysis_log.ContextMenuStrip = this.contextMenuStrip_trace_flow;
            this.listView_analysis_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_analysis_log.FullRowSelect = true;
            this.listView_analysis_log.GridLines = true;
            this.listView_analysis_log.HideSelection = false;
            this.listView_analysis_log.Location = new System.Drawing.Point(3, 3);
            this.listView_analysis_log.Name = "listView_analysis_log";
            this.listView_analysis_log.Size = new System.Drawing.Size(1114, 577);
            this.listView_analysis_log.TabIndex = 6;
            this.listView_analysis_log.UseCompatibleStateImageBehavior = false;
            this.listView_analysis_log.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "方向";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "ServiceCmd";
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "SSOReq";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "载荷大小(byte)";
            this.columnHeader7.Width = 106;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "载荷数据";
            this.columnHeader12.Width = 740;
            // 
            // contextMenuStrip_trace_flow
            // 
            this.contextMenuStrip_trace_flow.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制载荷数据ToolStripMenuItem1});
            this.contextMenuStrip_trace_flow.Name = "contextMenuStrip_trace_flow";
            this.contextMenuStrip_trace_flow.Size = new System.Drawing.Size(149, 26);
            // 
            // 复制载荷数据ToolStripMenuItem1
            // 
            this.复制载荷数据ToolStripMenuItem1.Name = "复制载荷数据ToolStripMenuItem1";
            this.复制载荷数据ToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.复制载荷数据ToolStripMenuItem1.Text = "复制载荷数据";
            this.复制载荷数据ToolStripMenuItem1.Click += new System.EventHandler(this.复制载荷数据ToolStripMenuItem1_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1120, 583);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "HTTP服务器";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button_clean_httpserver_log);
            this.groupBox5.Controls.Add(this.button_stop_httpserver);
            this.groupBox5.Controls.Add(this.button_start_httpserver);
            this.groupBox5.Controls.Add(this.textBox_httpserver_port);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Location = new System.Drawing.Point(3, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1114, 49);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "配置";
            // 
            // button_stop_httpserver
            // 
            this.button_stop_httpserver.Location = new System.Drawing.Point(207, 18);
            this.button_stop_httpserver.Name = "button_stop_httpserver";
            this.button_stop_httpserver.Size = new System.Drawing.Size(75, 23);
            this.button_stop_httpserver.TabIndex = 14;
            this.button_stop_httpserver.Text = "关闭";
            this.button_stop_httpserver.UseVisualStyleBackColor = true;
            this.button_stop_httpserver.Click += new System.EventHandler(this.Button_stop_httpserver_Click);
            // 
            // button_start_httpserver
            // 
            this.button_start_httpserver.Location = new System.Drawing.Point(126, 18);
            this.button_start_httpserver.Name = "button_start_httpserver";
            this.button_start_httpserver.Size = new System.Drawing.Size(75, 23);
            this.button_start_httpserver.TabIndex = 13;
            this.button_start_httpserver.Text = "启动";
            this.button_start_httpserver.UseVisualStyleBackColor = true;
            this.button_start_httpserver.Click += new System.EventHandler(this.Button_start_httpserver_ClickAsync);
            // 
            // textBox_httpserver_port
            // 
            this.textBox_httpserver_port.Location = new System.Drawing.Point(42, 18);
            this.textBox_httpserver_port.Name = "textBox_httpserver_port";
            this.textBox_httpserver_port.Size = new System.Drawing.Size(78, 21);
            this.textBox_httpserver_port.TabIndex = 12;
            this.textBox_httpserver_port.Text = "8899";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 11;
            this.label1.Text = "端口";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.richTextBox_httpserver_log);
            this.groupBox1.Location = new System.Drawing.Point(3, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1114, 515);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "日志";
            // 
            // richTextBox_httpserver_log
            // 
            this.richTextBox_httpserver_log.BackColor = System.Drawing.Color.Black;
            this.richTextBox_httpserver_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox_httpserver_log.ForeColor = System.Drawing.Color.LimeGreen;
            this.richTextBox_httpserver_log.Location = new System.Drawing.Point(3, 17);
            this.richTextBox_httpserver_log.Name = "richTextBox_httpserver_log";
            this.richTextBox_httpserver_log.ReadOnly = true;
            this.richTextBox_httpserver_log.Size = new System.Drawing.Size(1108, 495);
            this.richTextBox_httpserver_log.TabIndex = 0;
            this.richTextBox_httpserver_log.Text = "";
            this.richTextBox_httpserver_log.WordWrap = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button_tea_key_log_decrypt);
            this.tabPage4.Controls.Add(this.button_tea_copy_decrypt_data);
            this.tabPage4.Controls.Add(this.button_tea_decrypt);
            this.tabPage4.Controls.Add(this.button_tea_encrypt);
            this.tabPage4.Controls.Add(this.textBox_tea_decrypt_data);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.textBox_tea_encrypt_data);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.textBox_tea_key);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1120, 583);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "TEA加解密";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button_tea_key_log_decrypt
            // 
            this.button_tea_key_log_decrypt.Location = new System.Drawing.Point(693, 8);
            this.button_tea_key_log_decrypt.Name = "button_tea_key_log_decrypt";
            this.button_tea_key_log_decrypt.Size = new System.Drawing.Size(96, 23);
            this.button_tea_key_log_decrypt.TabIndex = 9;
            this.button_tea_key_log_decrypt.Text = "KEY日志解密";
            this.button_tea_key_log_decrypt.UseVisualStyleBackColor = true;
            this.button_tea_key_log_decrypt.Click += new System.EventHandler(this.Button_tea_key_log_decrypt_Click);
            // 
            // button_tea_copy_decrypt_data
            // 
            this.button_tea_copy_decrypt_data.Location = new System.Drawing.Point(582, 8);
            this.button_tea_copy_decrypt_data.Name = "button_tea_copy_decrypt_data";
            this.button_tea_copy_decrypt_data.Size = new System.Drawing.Size(96, 23);
            this.button_tea_copy_decrypt_data.TabIndex = 8;
            this.button_tea_copy_decrypt_data.Text = "复制解密数据";
            this.button_tea_copy_decrypt_data.UseVisualStyleBackColor = true;
            this.button_tea_copy_decrypt_data.Click += new System.EventHandler(this.Button_tea_copy_decrypt_data_Click);
            // 
            // button_tea_decrypt
            // 
            this.button_tea_decrypt.Location = new System.Drawing.Point(490, 8);
            this.button_tea_decrypt.Name = "button_tea_decrypt";
            this.button_tea_decrypt.Size = new System.Drawing.Size(75, 23);
            this.button_tea_decrypt.TabIndex = 7;
            this.button_tea_decrypt.Text = "解密";
            this.button_tea_decrypt.UseVisualStyleBackColor = true;
            this.button_tea_decrypt.Click += new System.EventHandler(this.Button_tea_decrypt_Click);
            // 
            // button_tea_encrypt
            // 
            this.button_tea_encrypt.Location = new System.Drawing.Point(396, 8);
            this.button_tea_encrypt.Name = "button_tea_encrypt";
            this.button_tea_encrypt.Size = new System.Drawing.Size(75, 23);
            this.button_tea_encrypt.TabIndex = 6;
            this.button_tea_encrypt.Text = "加密";
            this.button_tea_encrypt.UseVisualStyleBackColor = true;
            this.button_tea_encrypt.Click += new System.EventHandler(this.Button_tea_encrypt_Click);
            // 
            // textBox_tea_decrypt_data
            // 
            this.textBox_tea_decrypt_data.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_tea_decrypt_data.Location = new System.Drawing.Point(7, 283);
            this.textBox_tea_decrypt_data.Multiline = true;
            this.textBox_tea_decrypt_data.Name = "textBox_tea_decrypt_data";
            this.textBox_tea_decrypt_data.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_tea_decrypt_data.Size = new System.Drawing.Size(1107, 297);
            this.textBox_tea_decrypt_data.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 257);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "解密数据";
            // 
            // textBox_tea_encrypt_data
            // 
            this.textBox_tea_encrypt_data.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_tea_encrypt_data.Location = new System.Drawing.Point(7, 70);
            this.textBox_tea_encrypt_data.Multiline = true;
            this.textBox_tea_encrypt_data.Name = "textBox_tea_encrypt_data";
            this.textBox_tea_encrypt_data.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_tea_encrypt_data.Size = new System.Drawing.Size(1107, 171);
            this.textBox_tea_encrypt_data.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "加密数据";
            // 
            // textBox_tea_key
            // 
            this.textBox_tea_key.Location = new System.Drawing.Point(42, 8);
            this.textBox_tea_key.Name = "textBox_tea_key";
            this.textBox_tea_key.Size = new System.Drawing.Size(332, 21);
            this.textBox_tea_key.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "密钥";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1120, 583);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "工具";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_nick);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_tgtkey);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_A3);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_A2);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_A1);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_d2key);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_bssid);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_imei);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_imsi);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_mac);
            this.groupBox6.Controls.Add(this.textBox_tool_hookdata_androidId);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Location = new System.Drawing.Point(380, 209);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(535, 300);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Hook数据";
            // 
            // textBox_tool_hookdata_nick
            // 
            this.textBox_tool_hookdata_nick.Location = new System.Drawing.Point(336, 48);
            this.textBox_tool_hookdata_nick.Name = "textBox_tool_hookdata_nick";
            this.textBox_tool_hookdata_nick.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_nick.TabIndex = 22;
            // 
            // textBox_tool_hookdata_tgtkey
            // 
            this.textBox_tool_hookdata_tgtkey.Location = new System.Drawing.Point(336, 16);
            this.textBox_tool_hookdata_tgtkey.Name = "textBox_tool_hookdata_tgtkey";
            this.textBox_tool_hookdata_tgtkey.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_tgtkey.TabIndex = 21;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(274, 51);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 20;
            this.label22.Text = "Nick";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(274, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 19;
            this.label21.Text = "TGTKEY";
            // 
            // textBox_tool_hookdata_A3
            // 
            this.textBox_tool_hookdata_A3.Location = new System.Drawing.Point(71, 258);
            this.textBox_tool_hookdata_A3.Name = "textBox_tool_hookdata_A3";
            this.textBox_tool_hookdata_A3.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_A3.TabIndex = 18;
            // 
            // textBox_tool_hookdata_A2
            // 
            this.textBox_tool_hookdata_A2.Location = new System.Drawing.Point(71, 231);
            this.textBox_tool_hookdata_A2.Name = "textBox_tool_hookdata_A2";
            this.textBox_tool_hookdata_A2.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_A2.TabIndex = 17;
            // 
            // textBox_tool_hookdata_A1
            // 
            this.textBox_tool_hookdata_A1.Location = new System.Drawing.Point(71, 203);
            this.textBox_tool_hookdata_A1.Name = "textBox_tool_hookdata_A1";
            this.textBox_tool_hookdata_A1.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_A1.TabIndex = 16;
            // 
            // textBox_tool_hookdata_d2key
            // 
            this.textBox_tool_hookdata_d2key.Location = new System.Drawing.Point(71, 173);
            this.textBox_tool_hookdata_d2key.Name = "textBox_tool_hookdata_d2key";
            this.textBox_tool_hookdata_d2key.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_d2key.TabIndex = 15;
            // 
            // textBox_tool_hookdata_bssid
            // 
            this.textBox_tool_hookdata_bssid.Location = new System.Drawing.Point(71, 141);
            this.textBox_tool_hookdata_bssid.Name = "textBox_tool_hookdata_bssid";
            this.textBox_tool_hookdata_bssid.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_bssid.TabIndex = 14;
            // 
            // textBox_tool_hookdata_imei
            // 
            this.textBox_tool_hookdata_imei.Location = new System.Drawing.Point(71, 109);
            this.textBox_tool_hookdata_imei.Name = "textBox_tool_hookdata_imei";
            this.textBox_tool_hookdata_imei.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_imei.TabIndex = 13;
            // 
            // textBox_tool_hookdata_imsi
            // 
            this.textBox_tool_hookdata_imsi.Location = new System.Drawing.Point(71, 80);
            this.textBox_tool_hookdata_imsi.Name = "textBox_tool_hookdata_imsi";
            this.textBox_tool_hookdata_imsi.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_imsi.TabIndex = 12;
            // 
            // textBox_tool_hookdata_mac
            // 
            this.textBox_tool_hookdata_mac.Location = new System.Drawing.Point(71, 48);
            this.textBox_tool_hookdata_mac.Name = "textBox_tool_hookdata_mac";
            this.textBox_tool_hookdata_mac.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_mac.TabIndex = 11;
            // 
            // textBox_tool_hookdata_androidId
            // 
            this.textBox_tool_hookdata_androidId.Location = new System.Drawing.Point(71, 16);
            this.textBox_tool_hookdata_androidId.Name = "textBox_tool_hookdata_androidId";
            this.textBox_tool_hookdata_androidId.Size = new System.Drawing.Size(188, 21);
            this.textBox_tool_hookdata_androidId.TabIndex = 10;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 264);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(17, 12);
            this.label20.TabIndex = 9;
            this.label20.Text = "A3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 237);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 12);
            this.label19.TabIndex = 8;
            this.label19.Text = "A2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 209);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(17, 12);
            this.label18.TabIndex = 7;
            this.label18.Text = "A1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 178);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 12);
            this.label17.TabIndex = 6;
            this.label17.Text = "D2Key";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 146);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 12);
            this.label16.TabIndex = 5;
            this.label16.Text = "BSSID";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "IMEI";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 86);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 3;
            this.label14.Text = "IMSI";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "Mac";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "AndroidID";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.textBox_tool_qqencrypt_pass);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.button_tool_qqencrypt_copy);
            this.groupBox4.Controls.Add(this.textBox_tool_qqencrypt_ret);
            this.groupBox4.Controls.Add(this.button_tool_qqencrypt_calc);
            this.groupBox4.Controls.Add(this.textBox_tool_qqencrypt_qq);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(380, 88);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(535, 115);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "QQ密码加密";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(233, 12);
            this.label11.TabIndex = 11;
            this.label11.Text = "md5(md5(pass) + 00 00 00 00 + hex(qq))";
            // 
            // textBox_tool_qqencrypt_pass
            // 
            this.textBox_tool_qqencrypt_pass.Location = new System.Drawing.Point(302, 16);
            this.textBox_tool_qqencrypt_pass.Name = "textBox_tool_qqencrypt_pass";
            this.textBox_tool_qqencrypt_pass.Size = new System.Drawing.Size(152, 21);
            this.textBox_tool_qqencrypt_pass.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(251, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "密码";
            // 
            // button_tool_qqencrypt_copy
            // 
            this.button_tool_qqencrypt_copy.Location = new System.Drawing.Point(463, 51);
            this.button_tool_qqencrypt_copy.Name = "button_tool_qqencrypt_copy";
            this.button_tool_qqencrypt_copy.Size = new System.Drawing.Size(61, 23);
            this.button_tool_qqencrypt_copy.TabIndex = 8;
            this.button_tool_qqencrypt_copy.Text = "复制";
            this.button_tool_qqencrypt_copy.UseVisualStyleBackColor = true;
            this.button_tool_qqencrypt_copy.Click += new System.EventHandler(this.Button_tool_qqencrypt_copy_Click);
            // 
            // textBox_tool_qqencrypt_ret
            // 
            this.textBox_tool_qqencrypt_ret.Location = new System.Drawing.Point(57, 53);
            this.textBox_tool_qqencrypt_ret.Name = "textBox_tool_qqencrypt_ret";
            this.textBox_tool_qqencrypt_ret.Size = new System.Drawing.Size(397, 21);
            this.textBox_tool_qqencrypt_ret.TabIndex = 7;
            // 
            // button_tool_qqencrypt_calc
            // 
            this.button_tool_qqencrypt_calc.Location = new System.Drawing.Point(463, 16);
            this.button_tool_qqencrypt_calc.Name = "button_tool_qqencrypt_calc";
            this.button_tool_qqencrypt_calc.Size = new System.Drawing.Size(61, 23);
            this.button_tool_qqencrypt_calc.TabIndex = 6;
            this.button_tool_qqencrypt_calc.Text = "计算";
            this.button_tool_qqencrypt_calc.UseVisualStyleBackColor = true;
            this.button_tool_qqencrypt_calc.Click += new System.EventHandler(this.Button_tool_qqencrypt_calc_Click);
            // 
            // textBox_tool_qqencrypt_qq
            // 
            this.textBox_tool_qqencrypt_qq.Location = new System.Drawing.Point(57, 17);
            this.textBox_tool_qqencrypt_qq.Name = "textBox_tool_qqencrypt_qq";
            this.textBox_tool_qqencrypt_qq.Size = new System.Drawing.Size(152, 21);
            this.textBox_tool_qqencrypt_qq.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "结果";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "QQ";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button_tool_md5_copy_once);
            this.groupBox3.Controls.Add(this.textBox_tool_md5_once);
            this.groupBox3.Controls.Add(this.button_tool_md5_calc);
            this.groupBox3.Controls.Add(this.textBox_tool_md5_input);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(380, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(535, 76);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "MD5计算";
            // 
            // button_tool_md5_copy_once
            // 
            this.button_tool_md5_copy_once.Location = new System.Drawing.Point(463, 42);
            this.button_tool_md5_copy_once.Name = "button_tool_md5_copy_once";
            this.button_tool_md5_copy_once.Size = new System.Drawing.Size(61, 23);
            this.button_tool_md5_copy_once.TabIndex = 8;
            this.button_tool_md5_copy_once.Text = "复制";
            this.button_tool_md5_copy_once.UseVisualStyleBackColor = true;
            this.button_tool_md5_copy_once.Click += new System.EventHandler(this.Button_tool_md5_copy_once_Click);
            // 
            // textBox_tool_md5_once
            // 
            this.textBox_tool_md5_once.Location = new System.Drawing.Point(57, 44);
            this.textBox_tool_md5_once.Name = "textBox_tool_md5_once";
            this.textBox_tool_md5_once.Size = new System.Drawing.Size(397, 21);
            this.textBox_tool_md5_once.TabIndex = 7;
            // 
            // button_tool_md5_calc
            // 
            this.button_tool_md5_calc.Location = new System.Drawing.Point(463, 16);
            this.button_tool_md5_calc.Name = "button_tool_md5_calc";
            this.button_tool_md5_calc.Size = new System.Drawing.Size(61, 23);
            this.button_tool_md5_calc.TabIndex = 6;
            this.button_tool_md5_calc.Text = "计算";
            this.button_tool_md5_calc.UseVisualStyleBackColor = true;
            this.button_tool_md5_calc.Click += new System.EventHandler(this.Button_tool_md5_calc_Click);
            // 
            // textBox_tool_md5_input
            // 
            this.textBox_tool_md5_input.Location = new System.Drawing.Point(57, 17);
            this.textBox_tool_md5_input.Name = "textBox_tool_md5_input";
            this.textBox_tool_md5_input.Size = new System.Drawing.Size(397, 21);
            this.textBox_tool_md5_input.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "MD5一次";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "内容";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.button_tool_save_keys);
            this.groupBox2.Controls.Add(this.button_tool_read_keys);
            this.groupBox2.Controls.Add(this.textBox_tool_keys);
            this.groupBox2.Location = new System.Drawing.Point(3, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(367, 574);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KEY日志";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "一行一个";
            // 
            // button_tool_save_keys
            // 
            this.button_tool_save_keys.Location = new System.Drawing.Point(100, 20);
            this.button_tool_save_keys.Name = "button_tool_save_keys";
            this.button_tool_save_keys.Size = new System.Drawing.Size(88, 23);
            this.button_tool_save_keys.TabIndex = 6;
            this.button_tool_save_keys.Text = "保存KEY日志";
            this.button_tool_save_keys.UseVisualStyleBackColor = true;
            this.button_tool_save_keys.Click += new System.EventHandler(this.Button_tool_save_keys_Click);
            // 
            // button_tool_read_keys
            // 
            this.button_tool_read_keys.Location = new System.Drawing.Point(6, 20);
            this.button_tool_read_keys.Name = "button_tool_read_keys";
            this.button_tool_read_keys.Size = new System.Drawing.Size(88, 23);
            this.button_tool_read_keys.TabIndex = 5;
            this.button_tool_read_keys.Text = "读取KEY日志";
            this.button_tool_read_keys.UseVisualStyleBackColor = true;
            this.button_tool_read_keys.Click += new System.EventHandler(this.Button_tool_read_keys_Click);
            // 
            // textBox_tool_keys
            // 
            this.textBox_tool_keys.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_tool_keys.Location = new System.Drawing.Point(6, 49);
            this.textBox_tool_keys.Multiline = true;
            this.textBox_tool_keys.Name = "textBox_tool_keys";
            this.textBox_tool_keys.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_tool_keys.Size = new System.Drawing.Size(354, 519);
            this.textBox_tool_keys.TabIndex = 4;
            // 
            // button_stop_capture
            // 
            this.button_stop_capture.Location = new System.Drawing.Point(546, 10);
            this.button_stop_capture.Name = "button_stop_capture";
            this.button_stop_capture.Size = new System.Drawing.Size(75, 23);
            this.button_stop_capture.TabIndex = 8;
            this.button_stop_capture.Text = "停止";
            this.button_stop_capture.UseVisualStyleBackColor = true;
            this.button_stop_capture.Click += new System.EventHandler(this.Button_stop_capture_Click);
            // 
            // button_clear_packet_log
            // 
            this.button_clear_packet_log.Location = new System.Drawing.Point(627, 10);
            this.button_clear_packet_log.Name = "button_clear_packet_log";
            this.button_clear_packet_log.Size = new System.Drawing.Size(75, 23);
            this.button_clear_packet_log.TabIndex = 10;
            this.button_clear_packet_log.Text = "清空";
            this.button_clear_packet_log.UseVisualStyleBackColor = true;
            this.button_clear_packet_log.Click += new System.EventHandler(this.Button_clear_packet_log_Click);
            // 
            // button_clean_httpserver_log
            // 
            this.button_clean_httpserver_log.Location = new System.Drawing.Point(288, 18);
            this.button_clean_httpserver_log.Name = "button_clean_httpserver_log";
            this.button_clean_httpserver_log.Size = new System.Drawing.Size(75, 23);
            this.button_clean_httpserver_log.TabIndex = 15;
            this.button_clean_httpserver_log.Text = "清空";
            this.button_clean_httpserver_log.UseVisualStyleBackColor = true;
            this.button_clean_httpserver_log.Click += new System.EventHandler(this.Button_clean_httpserver_log_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 649);
            this.Controls.Add(this.button_clear_packet_log);
            this.Controls.Add(this.button_stop_capture);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button_load_device);
            this.Controls.Add(this.button_start_capture);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox_network_adapter);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "YgAndroidQQSniffer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.contextMenuStrip_analysis.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip_packets.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.contextMenuStrip_trace_flow.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_network_adapter;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_analysis;
        private System.Windows.Forms.ToolStripMenuItem 到10进制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 计算字节数ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 转换ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 到文本ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 到QQToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hex到时间ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tLV格式化ToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_start_capture;
        private System.Windows.Forms.Button button_load_device;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button_stop_capture;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_packets;
        private System.Windows.Forms.ToolStripMenuItem 复制载荷数据ToolStripMenuItem;
        private System.Windows.Forms.Button button_clear_packet_log;
        private System.Windows.Forms.ToolStripMenuItem 追踪流ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tEA解密ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 十六个0ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kEY日志ToolStripMenuItem;
        private System.Windows.Forms.ListView listView_analysis_log;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox richTextBox_httpserver_log;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_trace_flow;
        private System.Windows.Forms.ToolStripMenuItem 复制载荷数据ToolStripMenuItem1;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ToolStripMenuItem 选中字节计算换行ToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox textBox_tea_key;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_tea_decrypt_data;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_tea_encrypt_data;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_tea_copy_decrypt_data;
        private System.Windows.Forms.Button button_tea_decrypt;
        private System.Windows.Forms.Button button_tea_encrypt;
        private System.Windows.Forms.Button button_tea_key_log_decrypt;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_tool_save_keys;
        private System.Windows.Forms.Button button_tool_read_keys;
        private System.Windows.Forms.TextBox textBox_tool_keys;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_tool_md5_copy_once;
        private System.Windows.Forms.TextBox textBox_tool_md5_once;
        private System.Windows.Forms.Button button_tool_md5_calc;
        private System.Windows.Forms.TextBox textBox_tool_md5_input;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button_tool_qqencrypt_copy;
        private System.Windows.Forms.TextBox textBox_tool_qqencrypt_ret;
        private System.Windows.Forms.Button button_tool_qqencrypt_calc;
        private System.Windows.Forms.TextBox textBox_tool_qqencrypt_qq;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_tool_qqencrypt_pass;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView listView_packet_log;
        private System.Windows.Forms.ColumnHeader Index;
        private System.Windows.Forms.ColumnHeader Orientation;
        private System.Windows.Forms.ColumnHeader SrcIp;
        private System.Windows.Forms.ColumnHeader DstIp;
        private System.Windows.Forms.ColumnHeader time;
        private System.Windows.Forms.ColumnHeader PayloadLen;
        private System.Windows.Forms.ColumnHeader PayloadData;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.RichTextBox richTextBox_log;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button_stop_httpserver;
        private System.Windows.Forms.Button button_start_httpserver;
        private System.Windows.Forms.TextBox textBox_httpserver_port;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_imei;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_imsi;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_mac;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_bssid;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_A3;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_A2;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_A1;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_d2key;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_androidId;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_nick;
        private System.Windows.Forms.TextBox textBox_tool_hookdata_tgtkey;
        private System.Windows.Forms.ToolStripMenuItem hex到IPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一键格式化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Inflater解压ToolStripMenuItem;
        private System.Windows.Forms.Button button_clean_httpserver_log;
    }
}

