﻿using App.Metrics.Concurrency;
using DotNetty.Buffers;
using DotNetty.Common.Utilities;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
using NLog;
using SharpPcap;
using SharpPcap.LibPcap;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using YgAndroidQQSniffer.Component;
using YgAndroidQQSniffer.Extension;

namespace YgAndroidQQSniffer
{
    public partial class FormMain : Form
    {
        public static FormMain Form { get; private set; }
        public static Logger Logger { get; set; } = LogManager.GetCurrentClassLogger();
        #region Hook Data
        private string _androidId = string.Empty;
        public string AndroidId { get => _androidId; set { _androidId = value; ThreadSafeUpdate(() => textBox_tool_hookdata_androidId.Text = _androidId); } }
        private string _mac = string.Empty;
        public string Mac { get => _mac; set { _mac = value; ThreadSafeUpdate(() => textBox_tool_hookdata_mac.Text = _mac); } }
        private string _imsi = string.Empty;
        public string IMSI { get => _imsi; set { _imsi = value; ThreadSafeUpdate(() => textBox_tool_hookdata_imsi.Text = _imsi); } }
        private string _imei = string.Empty;
        public string IMEI { get => _imei; set { _imei = value; ThreadSafeUpdate(() => textBox_tool_hookdata_imei.Text = _imei); } }
        private string _bssid = string.Empty;
        public string BSSID { get => _bssid; set { _bssid = value; ThreadSafeUpdate(() => textBox_tool_hookdata_bssid.Text = _bssid); } }
        private string _d2key = string.Empty;
        public string D2KEY { get => _d2key; set { _d2key = value; ThreadSafeUpdate(() => textBox_tool_hookdata_d2key.Text = _d2key); } }
        private string _a1 = string.Empty;
        public string A1 { get => _a1; set { _a1 = value; ThreadSafeUpdate(() => textBox_tool_hookdata_A1.Text = _a1); } }
        private string _a2 = string.Empty;
        public string A2 { get => _a2; set { _a2 = value; ThreadSafeUpdate(() => textBox_tool_hookdata_A2.Text = _a2); } }
        private string _a3 = string.Empty;
        public string A3 { get => _a3; set { _a3 = value; ThreadSafeUpdate(() => textBox_tool_hookdata_A3.Text = _a3); } }
        private string _tgtkey = string.Empty;
        public string TGTKEY { get => _tgtkey; set { _tgtkey = value; ThreadSafeUpdate(() => textBox_tool_hookdata_tgtkey.Text = _tgtkey); } }
        private string _nick = string.Empty;
        public string Nick { get => _nick; set { _nick = value; ThreadSafeUpdate(() => textBox_tool_hookdata_nick.Text = _nick); } }
        #endregion
        public FormMain()
        {
            InitializeComponent();
        }
        #region FormMain Load
        private void FormMain_Load(object sender, EventArgs e)
        {
            Form = this;
            OptimizeListView();
            ConfigNLog();
        }

        private void OptimizeListView()
        {
            listView_packet_log
              .GetType()
              .GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
              .SetValue(listView_packet_log, true, null);
            listView_analysis_log
                .GetType()
                .GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
                .SetValue(listView_packet_log, true, null);
        }

        private void ConfigNLog()
        {
            var xmlStream = new StringReader(Properties.Resources.NLogXmlConfig);
            var xmlReader = System.Xml.XmlReader.Create(xmlStream);
            NLog.LogManager.Configuration = new NLog.Config.XmlLoggingConfiguration(xmlReader, null);
        }
        #endregion
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Device != null)
            {
                if (Device.Started)
                {
                    Logger.Info(Device.Statistics.ToString());
                    Device.StopCapture();
                    Device.Close();
                }
            }
        }
        private void ThreadSafeUpdate(Action action)
        {
            Invoke(action);
        }

        /// <summary>
        /// 当前下拉框选中的网卡
        /// </summary>
        private ICaptureDevice Device { get; set; }
        /// <summary>
        /// 当前下拉框选中的网卡的IP
        /// </summary>
        private string NetworkAdapterIpAddr { get; set; }

        /// <summary>
        /// 读取网卡
        /// </summary>
        private void LoadDevice()
        {
            if (Device != null)
            {
                CaptureDeviceList.Instance.Refresh();
                return;
            }
            comboBox_network_adapter.Items.Clear();
            try
            {
                foreach (PcapDevice device in CaptureDeviceList.Instance)
                {
                    comboBox_network_adapter.Items.Add(new DeviceItem() { Device = device });
                }
                if (comboBox_network_adapter.Items.Count > 0)
                {
                    comboBox_network_adapter.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ComboBox_network_adapter_SelectedIndexChanged(object sender, EventArgs e)
        {
            Device = CaptureDeviceList.Instance[comboBox_network_adapter.SelectedIndex];
            NetworkAdapterIpAddr = ((DeviceItem)comboBox_network_adapter.SelectedItem).IpAddr;
        }

        private void 到10进制ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\n", "").Replace("\r", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {
                MessageBox.Show(Util.HexToDec(selected_text).ToString(), "提示");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void 计算字节数ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\n", "").Replace("\r", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            if (selected_text.Length % 2 != 0)
            {
                MessageBox.Show("请选择完整字节", "提示");
                return;
            }
            if (!Regex.IsMatch(selected_text, "^[0-9a-fA-F]+$"))
            {
                MessageBox.Show("字节数据不合法", "提示");
                return;
            }
            MessageBox.Show((selected_text.Length / 2).ToString(), "提示");
        }

        #region 转换
        private void 到文本ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {
                string str = $"//[{Util.HexToString(HexUtil.DecodeHex(selected_text), Encoding.UTF8)}]";
                Console.WriteLine(str);
                Log(str);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void 到QQToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {
                string ret = $"//[QQ: {Util.HexToDec(selected_text)}]";
                Log(ret);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void Hex到时间ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {
                string ret = $"//[Time: {Util.HexToDateTime(selected_text)}]";
                Log(ret);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void Hex到IPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {
                Log($" //[Ip: {Util.LongToIpEndian(Util.HexToDec(selected_text))}]");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void Inflater解压ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.Text.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;

            try
            {
                var outputStream = new MemoryStream();
                using (var compressedStream = new MemoryStream(HexUtil.DecodeHex(selected_text)))
                using (var inputStream = new InflaterInputStream(compressedStream))
                {
                    inputStream.CopyTo(outputStream);
                    outputStream.Position = 0;
                    Log($"\n\n[{outputStream.ToArray().HexDump()}]\n\n");
                }
            }
            catch (Exception) { }
        }
        #endregion

        private void TLV格式化ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            try
            {   
                var buf = Unpooled.WrappedBuffer(HexUtil.DecodeHex(selected_text));
                string ret = new TLVParser.TLVFormatter().Parse(buf);
                Log($"\n{ret}\n");
                Console.WriteLine(ret);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder sb_all = new StringBuilder();
            foreach (ListViewItem item in listView_packet_log.Items)
            {
                if (item.Tag is PacketAnalyzer analysisPacket)
                {
                    sb_all.Append(analysisPacket.HexPayload);
                }
            }
            if (string.IsNullOrEmpty(sb_all.ToString())) return;
            List<byte[]> bytes = new List<byte[]>();
            List<PacketAnalyzer> analysisPackets = new List<PacketAnalyzer>();

            var buf = Unpooled.WrappedBuffer(HexUtil.DecodeHex(sb_all.ToString()));
            try
            {
                try
                {
                    while (buf.IsReadable())
                    {
                        byte[] tag = new byte[5];
                        buf.GetBytes(buf.ReaderIndex + 4, tag, 0, 5);
                        switch (tag.HexDump())
                        {
                            case "00 00 00 0A 00":
                            case "00 00 00 0A 01":
                            case "00 00 00 0A 02":
                            case "00 00 00 0B 00":
                            case "00 00 00 0B 01":
                            case "00 00 00 0B 02":
                                int pkg_len = buf.GetInt(buf.ReaderIndex);
                                byte[] pkg_payload = new byte[pkg_len];
                                if (buf.ReadableBytes >= pkg_payload.Length)
                                {
                                    buf.ReadBytes(pkg_payload, 0, pkg_payload.Length);
                                    bytes.Add(pkg_payload);
                                }
                                break;
                            default:
                                buf.ReadBytes(9);
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.Error(ex, ex.Message);
                }
                foreach (byte[] payload in bytes)
                {
                    analysisPackets.Add(new PacketAnalyzer()
                    {
                        Payload = payload
                    });
                }
                listView_analysis_log.Items.Clear();
                foreach (var item in analysisPackets)
                {
                    try
                    {
                        item.Deserialize();
                        Logger.Info(item.ToString());
                        var lvi = new ListViewItem()
                        {
                            Text = item.Orientation,
                            SubItems =
                        {
                            item.ServiceCmd,
                            item.SSOReq,
                            //(item.Payload.Length + 4).ToString(),
                            item.Payload.Length.ToString(),
                            item.HexPayload
                        }
                        };
                        if (item.Orientation == "Send")
                        {
                            lvi.BackColor = Color.FromArgb(251, 237, 237);
                        }
                        else
                        {
                            lvi.BackColor = Color.FromArgb(237, 237, 251);
                        }
                        ThreadSafeUpdate(() => listView_analysis_log.Items.Add(lvi));
                    }
                    catch (Exception ex)
                    {
                        Logger.Error(ex, ex.Message + " hex: " + item.Payload.HexDump());
                    }
                }
            }
            finally
            {
                ReferenceCountUtil.Release(buf);
            }
        }

        private void Button_load_device_Click(object sender, EventArgs e)
        {
            LoadDevice();
        }

        private void Button_start_capture_Click(object sender, EventArgs e)
        {
            if (Device == null || Device.Started) return;
            listView_packet_log.Items.Clear();
            Common.Index = new AtomicInteger();
            Device.Open(DeviceMode.Normal, 1000);
            Device.Filter = "tcp port 8080 or tcp port 14000 or tcp port 443";
            Device.OnPacketArrival += new PacketArrivalEventHandler(Device_OnPacketArrival);
            Device.StartCapture();
        }

        private void Button_stop_capture_Click(object sender, EventArgs e)
        {
            if (Device != null)
            {
                try
                {
                    _dstIp = null;
                    Device.OnPacketArrival -= new PacketArrivalEventHandler(Device_OnPacketArrival);
                    Device.StopCapture();
                    Device.Close();
                }
                catch (Exception) { }
            }
        }

        private void Button_clear_packet_log_Click(object sender, EventArgs e)
        {
            listView_packet_log.Items.Clear();
            Common.Index = new AtomicInteger(0);
        }
        private string _dstIp { get; set; }
        private void Device_OnPacketArrival(object sender, CaptureEventArgs e)
        {
            var time = e.Packet.Timeval.Date.ToLocalTime();
            var len = e.Packet.Data.Length;
            var packet = PacketDotNet.Packet.ParsePacket(e.Packet.LinkLayerType, e.Packet.Data);
            var tcpPacket = packet.Extract<PacketDotNet.TcpPacket>();

            if (tcpPacket != null)
            {
                var ipPacket = (PacketDotNet.IPPacket)tcpPacket.ParentPacket;
                IPAddress srcIp = ipPacket.SourceAddress;
                IPAddress dstIp = ipPacket.DestinationAddress;
                int srcPort = tcpPacket.SourcePort;
                int dstPort = tcpPacket.DestinationPort;

                string data = tcpPacket.PayloadData.HexDump();
                int payload_len = tcpPacket.PayloadData.Length;

                if (payload_len == 0 || data == "00") return;

                string orientataion = string.Empty;
                if (srcIp.ToString() == NetworkAdapterIpAddr)
                {
                    orientataion = "Send";
                }
                else
                {
                    orientataion = "Recv";
                }
                ListViewItem lv = null;
                if (_dstIp == null)
                {
                    //首次捕获
                    var buf = Unpooled.WrappedBuffer(HexUtil.DecodeHex(data));
                    if (buf.ReadableBytes < 9) return;
                    byte[] tag = new byte[5];
                    buf.GetBytes(buf.ReaderIndex + 4, tag, 0, 5);
                    switch (tag.HexDump())
                    {
                        case "00 00 00 0A 00":
                        case "00 00 00 0A 01":
                        case "00 00 00 0A 02":
                        case "00 00 00 0B 00":
                        case "00 00 00 0B 01":
                        case "00 00 00 0B 02":
                            _dstIp = dstIp.ToString();
                            lv = new ListViewItem()
                            {
                                Text = Common.Index.Increment(1).ToString(),
                                SubItems =
                        {
                            orientataion,
                            $"{srcIp}:{srcPort}",
                            $"{dstIp}:{dstPort}",
                            time.ToString(),
                            payload_len.ToString(),
                            data,
                            tcpPacket.SequenceNumber.ToString(),
                            tcpPacket.AcknowledgmentNumber.ToString()
                        },
                                Tag = new PacketAnalyzer() { HexPayload = data }
                            };
                            break;
                        default:
                            break;
                    }

                    /*if (data.Contains("00 00 00 0A 02") || data.Contains("00 00 00 0A 01") || data.Contains("00 00 00 0A 00")
                        || data.Contains("00 00 00 0B 02") || data.Contains("00 00 00 0B 01") || data.Contains("00 00 00 0B 00"))
                    {
                        _dstIp = dstIp.ToString();
                    }*/
                    /*lv = new ListViewItem()
                    {
                        Text = Common.Index.Increment(1).ToString(),
                        SubItems =
                        {
                            orientataion,
                            $"{srcIp}:{srcPort}",
                            $"{dstIp}:{dstPort}",
                            time.ToString(),
                            payload_len.ToString(),
                            data,
                            tcpPacket.SequenceNumber.ToString(),
                            tcpPacket.AcknowledgmentNumber.ToString()
                        },
                        Tag = new PacketAnalyzer() { HexPayload = data }
                    };*/
                }
                else
                {
                    //dstIp toString valid
                    if (srcIp.ToString() == _dstIp || dstIp.ToString() == _dstIp)
                    {
                        lv = new ListViewItem()
                        {
                            Text = Common.Index.Increment(1).ToString(),
                            SubItems =
                        {
                            orientataion,
                            $"{srcIp}:{srcPort}",
                            $"{dstIp}:{dstPort}",
                            time.ToString(),
                            payload_len.ToString(),
                            data,
                            tcpPacket.SequenceNumber.ToString(),
                            tcpPacket.AcknowledgmentNumber.ToString()
                        },
                            Tag = new PacketAnalyzer() { HexPayload = data }
                        };
                    }
                }
                


                /*var item = new ListViewItem()
                {
                    Text = Common.Index.Increment(1).ToString(),
                    SubItems =
                        {
                            orientataion,
                            $"{srcIp}:{srcPort}",
                            $"{dstIp}:{dstPort}",
                            time.ToString(),
                            payload_len.ToString(),
                            data,
                            tcpPacket.SequenceNumber.ToString(),
                            tcpPacket.AcknowledgmentNumber.ToString()
                        },
                    Tag = new PacketAnalyzer() { HexPayload = data }
                };*/
                /*if (data.Contains("00 00 00 0A 02") || data.Contains("00 00 00 0A 01") || data.Contains("00 00 00 0A 00")
                    || data.Contains("00 00 00 0B 02") || data.Contains("00 00 00 0B 01") || data.Contains("00 00 00 0B 00"))
                {
                    if (orientataion == "Send")
                    {
                        item.BackColor = Color.FromArgb(251, 237, 237);
                    }
                    else
                    {
                        item.BackColor = Color.FromArgb(237, 237, 251);
                    }
                }*/

                ThreadSafeUpdate(() => 
                {
                    if (lv != null)
                    {
                        if (orientataion == "Send")
                        {
                            lv.BackColor = Color.FromArgb(251, 237, 237);
                        }
                        else
                        {
                            lv.BackColor = Color.FromArgb(237, 237, 251);
                        }
                        listView_packet_log.Items.Add(lv);
                    }
                });
            }
        }

        private void 复制载荷数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView_packet_log.SelectedItems.Count == 1)
            {
                Clipboard.SetText(listView_packet_log.SelectedItems[0].SubItems[6].Text);
            }
        }

        private void 追踪流ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView_packet_log.SelectedItems.Count != 1) return;
            ListViewItem selected_item = listView_packet_log.SelectedItems[0];
            string selected_item_seq = selected_item.SubItems[7].Text;
            string selected_item_ack = selected_item.SubItems[8].Text;

            Console.WriteLine("selected: " + selected_item_seq + " " + selected_item_ack);
            var pkgs = listView_packet_log.Items;
            List<string> sends = new List<string>();
            List<string> recvs = new List<string>();
            StringBuilder sb_send = new StringBuilder();
            StringBuilder sb_recv = new StringBuilder();
            StringBuilder sb_packets = new StringBuilder();
            foreach (ListViewItem pkg in pkgs)
            {
                string index = pkg.Text;
                string pkg_seq = pkg.SubItems[7].Text;
                string pkg_ack = pkg.SubItems[8].Text;
                string data = string.Empty;
                if (pkg.Tag is PacketAnalyzer analysisPacket)
                {
                    data = analysisPacket.HexPayload;
                }
                if (pkg_seq == selected_item_ack)
                {
                    Console.WriteLine($"recv: {data}");
                }
                else if (pkg_ack == selected_item_seq)
                {
                    Console.WriteLine($"send: {data}");
                }
                // 如果这个recv的包很大，比如收到了3个包，当我们检测到第一个包为recv包后
                // 需要再查找它余下的包
                selected_item_seq = pkg_seq;
                selected_item_ack = pkg_ack;
                sb_packets.Append(data);
            }
            List<byte[]> bytes = new List<byte[]>();
            List<PacketAnalyzer> analysisPackets = new List<PacketAnalyzer>();
            var buf = Unpooled.WrappedBuffer(HexUtil.DecodeHex(sb_packets.ToString()));

            try
            {
                while (buf.IsReadable())
                {
                    int pkg_len = buf.ReadInt();
                    byte[] tag = new byte[5];
                    buf.GetBytes(buf.ReaderIndex, tag, 0, 5);
                    switch (tag.HexDump())
                    {
                        case "00 00 00 0A 00":
                        case "00 00 00 0A 01":
                        case "00 00 00 0A 02":
                        case "00 00 00 0B 00":
                        case "00 00 00 0B 01":
                        case "00 00 00 0B 02":
                            byte[] pkg_payload = new byte[pkg_len - 4];
                            if (buf.ReadableBytes >= pkg_payload.Length)
                            {
                                buf.ReadBytes(pkg_payload, 0, pkg_payload.Length);
                                bytes.Add(pkg_payload);
                            }
                            break;
                        default:

                            break;
                    }
                    /*byte[] pkg_payload = new byte[pkg_len - 4];
                    if (buf.ReadableBytes >= pkg_payload.Length)
                    {
                        buf.ReadBytes(pkg_payload, 0, pkg_payload.Length);
                        bytes.Add(pkg_payload);
                    }
                    else
                    {
                        Logger.Warn("剩余字节大小不足，请检查追踪的流是否有问题！");
                        Console.WriteLine(Util.ReadRemainingBytes(buf).HexDump());

                        break;
                    }*/
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, ex.Message);
            }
            foreach (byte[] payload in bytes)
            {
                analysisPackets.Add(new PacketAnalyzer()
                {
                    Payload = payload
                });
            }
            listView_analysis_log.Items.Clear();
            foreach (var item in analysisPackets)
            {
                try
                {
                    item.Deserialize();
                    Logger.Info(item.ToString());
                    var lvi = new ListViewItem()
                    {
                        Text = item.Orientation,
                        SubItems =
                        {
                            item.ServiceCmd,
                            item.SSOReq,
                            (item.Payload.Length + 4).ToString(),
                            item.HexPayload
                        }
                    };
                    if (item.Orientation == "Send")
                    {
                        lvi.BackColor = Color.FromArgb(251, 237, 237);
                    }
                    else
                    {
                        lvi.BackColor = Color.FromArgb(237, 237, 251);
                    }
                    ThreadSafeUpdate(() => listView_analysis_log.Items.Add(lvi));
                }
                catch (Exception ex)
                {
                    Logger.Error(ex, ex.Message + " hex: " + item.Payload.HexDump());
                }
            }
        }
        #region TEA解密 右键菜单
        private string PrettyKeyDecryptDump(byte[] decrypt_data, DecryptionKey decryption_key)
        {
            string decryption_key_str = $"{decryption_key.Key} keyType={decryption_key.KeyType.GetDisplayDescription()}";
            if (decryption_key.KeyType == KeyType.SHARE_KEY)
            {
                decryption_key_str += $" prikey={decryption_key.PrivateKey}";
                decryption_key_str += $" pubkey={decryption_key.PublicKey}";
            }
            return $"\n\n[key={decryption_key_str}\n{decrypt_data.HexDump()}]\n\n";
        }
        private void 十六个0ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] data = HexUtil.DecodeHex(richTextBox_log.SelectedText);
                byte[] decrypt_data = Common.TeaKeyLogDecrypt(data, out DecryptionKey decryptionKey);
                if (decrypt_data != null)
                {
                    Log(PrettyKeyDecryptDump(decrypt_data, decryptionKey));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void KEY日志ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            byte[] decrypt_data = Common.TeaKeyLogDecrypt(HexUtil.DecodeHex(selected_text), out DecryptionKey decryptionKey);
            if (decrypt_data != null)
            {
                Log(PrettyKeyDecryptDump(decrypt_data, decryptionKey));
            }
        }

        private void 复制载荷数据ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (listView_analysis_log.SelectedItems.Count == 1)
            {
                Clipboard.SetText(listView_analysis_log.SelectedItems[0].SubItems[4].Text);
            }
        }
        #endregion
        private void 选中字节计算换行ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.SelectedText.Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;

            string old_text = Clipboard.GetText();
            int old_start = richTextBox_log.SelectionStart;
            int old_length = richTextBox_log.SelectionLength;
            try
            {
                long calc_len = Util.HexToDec(selected_text);
                richTextBox_log.SelectionStart = ((int)calc_len * 3) + old_start + old_length;
                richTextBox_log.SelectionLength = 0;
                Clipboard.SetText(Environment.NewLine + Environment.NewLine);
                richTextBox_log.Paste();
                Clipboard.SetText(old_text);
            }
            catch (Exception) { }
        }
        private void 一键格式化ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string selected_text = richTextBox_log.Text.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            if (string.IsNullOrEmpty(selected_text)) return;
            new PacketFormatter().Parse(Unpooled.WrappedBuffer(HexUtil.DecodeHex(selected_text)));
        }

        /// <summary>
        /// 将字符串打印到富文本编辑框中
        /// </summary>
        /// <param name="text"></param>
        private void Log(string text)
        {
            string old_text = Clipboard.GetText();
            int old_start = richTextBox_log.SelectionStart;
            int old_length = richTextBox_log.SelectionLength;
            richTextBox_log.Select(old_start + old_length, 0);
            Clipboard.SetText(text);
            richTextBox_log.Paste();
            Clipboard.SetText(old_text);
        }
        #region TAB HTTP服务器
        public HttpServer.HttpServer HttpServer { get; private set; }
        private async void Button_start_httpserver_ClickAsync(object sender, EventArgs e)
        {
            string port = textBox_httpserver_port.Text;
            if (string.IsNullOrEmpty(port))
            {
                port = "8899";
            }
            try
            {
                if (HttpServer == null || HttpServer.SocketChannel.Open == false)
                {
                    HttpServer = new HttpServer.HttpServer() { Port = int.Parse(port) };
                    HttpServer.SocketChannel = await HttpServer.StartAsync();
                    HttpServerLog("HTTP服务器启动成功");
                }
            }
            catch (Exception ex)
            {
                HttpServerLog("HTTP服务器启动失败 失败原因: {0}", ex.Message);
            }
        }

        private void Button_stop_httpserver_Click(object sender, EventArgs e)
        {
            if (HttpServer != null && HttpServer.SocketChannel.Open == true)
            {
                if (HttpServer.Stop())
                {
                    HttpServerLog("HTTP服务器关闭成功");
                }
            }
        }
        private void Button_clean_httpserver_log_Click(object sender, EventArgs e)
        {
            richTextBox_httpserver_log.Clear();
        }
        public void HttpServerLog(string text)
        {
            string output = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            output += " " + text + Environment.NewLine;
            ThreadSafeUpdate(() => richTextBox_httpserver_log.AppendText(output));
        }
        public void HttpServerLog(string text, params object[] args)
        {
            HttpServerLog(string.Format(text, args));
        }
        #endregion
        #region TAB TEA加解密
        private void Button_tea_encrypt_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] key = HexUtil.DecodeHex(textBox_tea_key.Text);
                byte[] data = HexUtil.DecodeHex(textBox_tea_encrypt_data.Text);
                byte[] ret = Tea.Encrypt(data, key);
                if (ret != null)
                {
                    textBox_tea_decrypt_data.Text = ret.HexDump();
                }
            }
            catch (Exception) { }
        }

        private void Button_tea_decrypt_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] key = HexUtil.DecodeHex(textBox_tea_key.Text);
                byte[] data = HexUtil.DecodeHex(textBox_tea_encrypt_data.Text);
                byte[] ret = Tea.Decrypt(data, key);
                if (ret != null)
                {
                    textBox_tea_decrypt_data.Text = ret.HexDump();
                }
            }
            catch (Exception) { }
        }

        private void Button_tea_copy_decrypt_data_Click(object sender, EventArgs e)
        {
            string ret = textBox_tea_decrypt_data.Text;
            if (!string.IsNullOrEmpty(ret))
            {
                Clipboard.SetText(ret);
            }
        }

        private void Button_tea_key_log_decrypt_Click(object sender, EventArgs e)
        {
            string encrypt_data = textBox_tea_encrypt_data.Text;
            if (string.IsNullOrEmpty(encrypt_data)) return;
            byte[] data = HexUtil.DecodeHex(encrypt_data);
            byte[] decrypt_data = Common.TeaKeyLogDecrypt(data, out DecryptionKey decryptionKey);
            if (decrypt_data != null)
            {
                textBox_tea_decrypt_data.Text = decrypt_data.HexDump();
                textBox_tea_key.Text = decryptionKey.Key;
            }
        }
        #endregion
        #region TAB 工具
        #region KEY日志
        private void Button_tool_read_keys_Click(object sender, EventArgs e)
        {
            List<DecryptionKey> keys = Common.Keys.ToList();
            HashSet<string> key_set = new HashSet<string>();
            string text = string.Empty;

            keys.ForEach(k => key_set.Add(k.Key));
            key_set.ToList().ForEach(k => text += k + Environment.NewLine);
            textBox_tool_keys.Text = text;
        }

        private void Button_tool_save_keys_Click(object sender, EventArgs e)
        {
            string keys_text = textBox_tool_keys.Text;
            string[] keys = keys_text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            HashSet<string> key_set = new HashSet<string>();
            Common.Keys.Clear();
            keys.ToList().ForEach(k => key_set.Add(k));
            key_set.ToList().ForEach(k => Common.Keys.AddLast(new DecryptionKey() { Key = k, KeyType = KeyType.CUSTOM_KEY }));
        }
        #endregion
        #region MD5计算
        private void Button_tool_md5_calc_Click(object sender, EventArgs e)
        {
            textBox_tool_md5_once.Text = textBox_tool_md5_input.Text.GenerateMD5().HexDump(); ;
        }

        private void Button_tool_md5_copy_once_Click(object sender, EventArgs e)
        {
            string ret = textBox_tool_md5_once.Text;
            if (!string.IsNullOrEmpty(ret))
            {
                Clipboard.SetText(textBox_tool_md5_once.Text);
            }
        }
        #endregion
        #region QQ密码加密
        private void Button_tool_qqencrypt_calc_Click(object sender, EventArgs e)
        {
            string qq = textBox_tool_qqencrypt_qq.Text;
            string pass = textBox_tool_qqencrypt_pass.Text;
            try
            {
                var buf = Unpooled.Buffer()
                .WriteBytes(Util.GenerateMD5Byte(pass))
                .WriteInt(0)
                .WriteInt((int)Convert.ToInt64(qq));

                textBox_tool_qqencrypt_ret.Text = buf.Copy().Array.GenerateMD5().HexDump(); ;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示");
            }
        }

        private void Button_tool_qqencrypt_copy_Click(object sender, EventArgs e)
        {
            string ret = textBox_tool_qqencrypt_ret.Text;
            if (!string.IsNullOrEmpty(ret))
            {
                Clipboard.SetText(textBox_tool_qqencrypt_ret.Text);
            }
        }
        #endregion

        #endregion
    }
}
